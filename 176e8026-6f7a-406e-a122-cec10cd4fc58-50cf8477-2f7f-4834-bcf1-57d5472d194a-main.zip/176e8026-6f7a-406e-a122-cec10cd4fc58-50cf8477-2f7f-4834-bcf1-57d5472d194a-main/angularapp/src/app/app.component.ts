import { Component, OnInit } from '@angular/core';
import { AuthService } from './services/auth.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'angularapp';
 
  userRole:string=''
  constructor(private authService:AuthService,private router:Router,private toastr:ToastrService) {
    let createdAt=localStorage.getItem("createdAt");
    console.log("Created At: ",createdAt);
    //created at time as milliseconds
    //take current time as 
    //now - both of them
    //we get time 1000*60*60=3600000
    //36000000-diff
    //if diff <0 then remove token
    //else greater than set in setTimeout call back.
    let currentTime=new Date().getTime();
    console.log(currentTime);
    let diff=currentTime-parseInt(createdAt);
    console.log("difference between current and created time ",diff);
    let toRemoveToken=60*60*1000*24-diff;
    console.log("available time to remove token ",toRemoveToken);
    console.log("This should be reflected in setTimeout")
    if(toRemoveToken<=0)
      {
        localStorage.clear();
        this.router.navigate(['/home']);
        this.toastr.error("Token expired please login again!!!!!");
      }
      if(toRemoveToken>0){
        setTimeout(()=>{
          localStorage.clear()
          this.toastr.error("Token expired please login again!!!!!");
        },toRemoveToken)
      }
  }
  ngOnInit(): void {
    this.getRole()
  }
  getRole(){
    this.userRole=this.authService.getRole();
  }
  isAdmin()
  {
    return this.authService.isAdmin();
  }
  isUser()
  {
    return this.authService.isCustomer();
  }
  isLoggedin()
  {
    return this.authService.isUserLoggedIn();
  }

}
