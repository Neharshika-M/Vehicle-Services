import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ErrorComponent } from './components/error/error.component';
import { UseraddappointmentComponent } from './components/useraddappointment/useraddappointment.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { UseraddfeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { UserviewappointmentComponent } from './components/userviewappointment/userviewappointment.component';
import { AdminviewappointmentComponent } from './components/adminviewappointment/adminviewappointment.component';
import { AdminviewserviceComponent } from './components/adminviewservice/adminviewservice.component';
import { AdminaddserviceComponent } from './components/adminaddservice/adminaddservice.component';
import { AdminviewuserdetailsComponent } from './components/adminviewuserdetails/adminviewuserdetails.component';
import { ProfileComponent } from './components/profile/profile.component';
import { UserGuard } from './user.guard';
import { AdminGuard } from './admin.guard';
import { EmailloginComponent } from './components/emaillogin/emaillogin.component';
const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch:'full'},
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'email/login',component:EmailloginComponent},
  {path:'register',component:RegistrationComponent},
  {path:'addFeedback',component:UseraddfeedbackComponent,canActivate:[UserGuard]},
  {path:'userviewFeedbacks',component:UserviewfeedbackComponent,canActivate:[UserGuard]},
  {path:'adminviewFeedbacks',component:AdminviewfeedbackComponent,canActivate:[AdminGuard]},
  {path:'useraddappointment',component:UseraddappointmentComponent,canActivate:[UserGuard]},
  {path:'userviewappointments',component:UserviewappointmentComponent,canActivate:[UserGuard]},
  {path:'adminviewappointments',component:AdminviewappointmentComponent,canActivate:[AdminGuard]},
  {path:'adminviewservice',component:AdminviewserviceComponent,canActivate:[AdminGuard]},
  {path:'adminaddservice',component:AdminaddserviceComponent,canActivate:[AdminGuard]},
  {path:'profile',component:ProfileComponent,canActivate:[UserGuard]},
{path:'adminviewuserdetails',component:AdminviewuserdetailsComponent,canActivate:[AdminGuard]},
  {
    path: 'error/404',
    component: ErrorComponent,
    data: {
      errorCode: 404,
      message: 'The page you are looking for does not exist.'
    }
  },
  {
    path: 'error/403',
    component: ErrorComponent,
    data: {
      errorCode: 403,
      message: 'You do not have permission to access this page.'
    }
  },
  {
    path: 'error/500',
    component: ErrorComponent,
    data: {
      errorCode: 500,
      message: 'Something went wrong. Please try again later.',
      showRetry: true
    }
  },
  {
    path: 'error/401',
    component: ErrorComponent,
    data: {
      errorCode: 401,
      message: 'Your session has expired. Please log in again.'
    }
  },
  {
    path: 'error/409',
    component: ErrorComponent,
    data: {
      errorCode: 409,
      message: 'User already exists.. Please try to login'
    }
  },
  {
    path: 'error/network',
    component: ErrorComponent,
    data: {
      errorCode: 0,
      message: 'No internet connection. Please check your network.',
      showRetry: true
    }
  },
  {
    path: '**',
    redirectTo: 'error/403'
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
