export interface VehicleMaintenance 
{
    id:number;
    serviceName:string;
    servicePrice:number;
    typeOfVehicle:string;
}
