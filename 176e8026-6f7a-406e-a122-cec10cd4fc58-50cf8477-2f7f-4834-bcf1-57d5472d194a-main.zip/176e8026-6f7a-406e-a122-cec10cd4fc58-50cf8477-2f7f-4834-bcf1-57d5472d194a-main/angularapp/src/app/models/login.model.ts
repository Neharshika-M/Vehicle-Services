export interface Login 
{
    username:string;
    password:string;
}


export interface Otp{
    email:string
    code:string
}