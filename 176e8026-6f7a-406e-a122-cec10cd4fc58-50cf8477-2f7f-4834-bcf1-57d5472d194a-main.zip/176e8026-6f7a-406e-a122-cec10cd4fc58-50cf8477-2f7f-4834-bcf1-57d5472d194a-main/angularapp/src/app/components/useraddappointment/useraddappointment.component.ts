import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { VehicleMaintenance } from 'src/app/models/vehicle-maintenance.model';
import { AppointmentService } from 'src/app/services/appointment.service';
import { AuthService } from 'src/app/services/auth.service';
import { VehicleService } from 'src/app/services/vehicle.service';

@Component({
  selector: 'app-useraddappointment',
  templateUrl: './useraddappointment.component.html',
  styleUrls: ['./useraddappointment.component.css']
})
export class UseraddappointmentComponent implements OnInit {

  userId = 1;
  services: any[] = [];
  showPopup = false;
  today: string;
  isLoading = false;

  // Pagination properties
  page = 1;
  pageSize = 5;

  constructor(
    private vehicleService: VehicleService,
    private appointmentService: AppointmentService,
    private router:Router,
    private authService:AuthService,
    private toastr:ToastrService
  ) {
    this.userId = this.authService.getAuthenticatedUserId();
  }

  ngOnInit(): void {
    if (!this.authService.isUserLoggedIn()) {
      this.router.navigate(['/home']);
    }
    this.loadServices();
    const current = new Date();
    this.today = current.toISOString().split('T')[0];
  }

  loadServices() {
    this.isLoading = true;
    this.vehicleService.getAllServices().subscribe((data: VehicleMaintenance[]) => {
      this.services = data.map(service => ({
        ...service,
        appointmentDate: '',
        location: ''
      }));
      this.isLoading = false;
    });
  }

  addAppointment(service: any) {
    if (service.appointmentDate !== '' && service.location !== '') {
      const appointment: any = {
        appointmentDate: service.appointmentDate,
        location: service.location,
        status: 'Pending',
        id: service.id,
        userId: this.userId
      };
      this.isLoading = true;
      this.appointmentService.addAppointment(appointment).subscribe({
        next: () => {
          console.log('Appointment added:', appointment);
          this.showPopup = true;
          this.isLoading = false;
        },
        error: (err) => {
          this.isLoading = false;
          console.error('Error occurred:', err);
          if (err.status === 0) {
            this.router.navigate(['/error/network']);
          } else if (err.status === 401) {
            this.router.navigate(['/error/401']);
          } else if (err.status === 403) {
            this.router.navigate(['/error/403']);
          } else if (err.status === 500) {
            this.router.navigate(['/error/500']);
          } else {
            this.router.navigate(['/error/404']);
          }
        }
      });
    } else {
      this.toastr.error('Please enter both date and location!');
    }
  }

  closePopup() {
    this.showPopup = false;
    this.router.navigate(['/userviewappointments']);
  }

  /**
   * Getter for the services on the current page.
   */
  get paginatedServices(): any[] {
    const startIndex = (this.page - 1) * this.pageSize;
    return this.services.slice(startIndex, startIndex + this.pageSize);
  }

  /**
   * Calculates the total number of pages.
   */
  totalPages(): number {
    return Math.ceil(this.services.length / this.pageSize);
  }

  /**
   * Changes the current page.
   */
  goToPage(p: number) {
    if (p >= 1 && p <= this.totalPages()) {
      this.page = p;
    }
  }
}
