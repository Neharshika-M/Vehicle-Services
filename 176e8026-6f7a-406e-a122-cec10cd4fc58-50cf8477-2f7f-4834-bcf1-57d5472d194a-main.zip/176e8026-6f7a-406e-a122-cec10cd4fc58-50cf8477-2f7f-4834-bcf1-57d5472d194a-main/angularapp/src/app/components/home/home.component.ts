import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  title: string = 'Vehicle Service';
  description: string = `Regular vehicle servicing is important for road safety, fuel efficiency, and maintaining the car's value.
  It can help prevent accidents by identifying and addressing potential issues with the brakes, tires, and suspension systems.
  Regular servicing can also improve fuel efficiency, which can lead to savings on fuel costs over time.
  Servicing your car regularly can also help maintain its value for resale.
  By performing routine checks on critical components such as the engine, transmission, and exhaust system,
  you can avoid major repairs down the road.
  This proactive approach can give you peace of mind, knowing that your vehicle is in optimal condition and less prone to unexpected breakdowns.`;

  constructor(private router:Router,private authService:AuthService) { }

  ngOnInit(): void {
    // if(!this.authService.isUserLoggedIn())
    // {
    //   this.router.navigate(['/login'])
    // }
  }

}