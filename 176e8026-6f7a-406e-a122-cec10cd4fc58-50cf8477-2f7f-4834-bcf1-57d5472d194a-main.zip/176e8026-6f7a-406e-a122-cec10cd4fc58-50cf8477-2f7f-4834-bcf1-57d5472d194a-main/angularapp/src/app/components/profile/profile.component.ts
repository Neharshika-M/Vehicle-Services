import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { UserdetailsService } from 'src/app/services/userdetails.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user: User = {};
  isEditing = false;
  isLoading=false
  profileImageUrl = 'assets/profilelogo.webp'; // Replace with actual image URL or logic

  isChangingPassword = false;
  isOldPasswordVerified = false;
  oldPassword = '';
  newPassword = '';
  confirmPassword = '';
  isForgotPassword=false;

  otpDigits: string[] = ['', '', '', '']; // 4-digit OTP
  otpSent=false;

  constructor(private userService: UserdetailsService,private authService:AuthService,private router:Router,private toastr:ToastrService) {}

  ngOnInit(): void {
    if(!this.authService.isUserLoggedIn())
    this.router.navigate(['/home'])
  this.isLoading=true
    const userId = this.authService.getAuthenticatedUserId(); // Replace with dynamic ID if needed
    this.userService.getUserById(userId).subscribe(data => {
      this.user = data;
      this.isLoading=false
    });
  }

  toggleEdit(): void {
    this.isEditing = !this.isEditing;
  }
  toggleChangePassword(): void {
    this.isChangingPassword = !this.isChangingPassword;
    this.isOldPasswordVerified = false;
    this.oldPassword = '';
    this.newPassword = '';
    this.confirmPassword = '';
    this.isForgotPassword=false;
    this.otpSent=false;
  }

  onSubmit(form: any): void {
    if (form.valid) {
      this.isLoading=false
      this.userService.updateUser(this.user).subscribe(updatedUser => {
        this.user = updatedUser;
        this.isEditing = false;
        this.isLoading=false
        this.toastr.success("User Updated Successfully!")
      });
    }
    
  }
  verifyOldPassword(): void {
    this.user={...this.user,password:this.oldPassword}
    this.isLoading=true
    this.userService.verifyPassword(this.user).subscribe(
      (data)=>{
        console.log(data)
        this.isOldPasswordVerified = true;
        this.isLoading=false
        this.toastr.success('Old password verified!');
      },
      (err)=>{
        console.log(err)
        this.isLoading=false
        this.toastr.error("Old Password is Incorrect! Try again!")
      }
    );
  }
  onPasswordSubmit(form: any): void {
    if (this.newPassword !== this.confirmPassword) {
      this.toastr.error('Passwords do not match!');
      return;
    }

    this.user={...this.user,password:this.newPassword}
    this.isLoading=true
    this.userService.updateUser(this.user).subscribe(
      (data) => {
        console.log(data)
        this.toastr.success('Password updated successfully!');
        this.toggleChangePassword();
        this.isLoading=false
        this.toggleEdit();
      },
      () => {
        this.isLoading=false
        this.toastr.error('Error updating password.');
      }
    );
  }
  isforgotPasswordToggle(){
    this.isForgotPassword=!this.isForgotPassword
    this.sendOtp()
  }
  sendOtp() {
      this.isLoading=true
      this.authService.loginWithEmail(this.user.email).subscribe((data)=>
      {
        console.log(data);
        this.toastr.success(data.message)
        this.isLoading=false
      },(error)=>
      {
        this.isLoading=false
        this.toastr.error(error.error.message)
        console.log(error.error.message);
      })
    }

    resendOtp(){
      this.isLoading=true
      this.authService.loginWithEmail(this.user.email).subscribe((data)=>
        {
          console.log(data);
          this.toastr.success(data.message)
          this.otpSent=true
          this.isLoading=false
        },(error)=>
        {
          this.isLoading=false
          this.toastr.error(error.error.message)
          console.log(error.error.message);
        })
    }
    
  trackByIndex(index: number): number {
    return index;
  }
  
  onOtpInput(event: any, index: number) {
    const value = event.target.value;
    if (value && index < this.otpDigits.length - 1) {
      const next = document.querySelectorAll<HTMLInputElement>('.otp-input')[index + 1];
      next?.focus();
    }
  }
  
  onOtpBackspace(event: KeyboardEvent, index: number) {
    if (!this.otpDigits[index] && index > 0) {
      const prev = document.querySelectorAll<HTMLInputElement>('.otp-input')[index - 1];
      prev?.focus();
    }
  }
  
  
    verifyOtp() {
      const isValid = this.otpDigits.every(d => d && d.trim() !== '');
      if (isValid) {
        this.isLoading=true
        this.authService.verifyOtpForUpdate({
          email: this.user.email,
          otp: this.otpDigits.join('')
        }).subscribe({
          next: (data) => {
            console.log(data);
            this.toastr.success('OTP Verified Successfully!');
            this.isLoading=false;
            this.isForgotPassword=false;
        this.isOldPasswordVerified = true;
          },
          error: (er) => {
            console.log(er.error.message)
            this.isLoading=false
            this.toastr.error(er.error.message);
          }
        });
      } else {
          this.isLoading=false
          this.toastr.error('Please enter all OTP digits');
      }
    }
}


















