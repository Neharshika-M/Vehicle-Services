
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-adminnavbar',
  templateUrl: './adminnavbar.component.html',
  styleUrls: ['./adminnavbar.component.css']
})
export class AdminnavbarComponent implements OnInit {
  showDropdown = false;
  showLogoutPopup = false;
  isLoggedIn = false;
  username:string=''
  constructor(private authservice:AuthService,private router:Router,private authService:AuthService) { }

  ngOnInit(): void 
  {
    if(!this.authService.isUserLoggedIn())
    this.router.navigate(['/home'])
    this.getusername();
  }
  getusername()
  {
    this.username=this.authservice.getUsername();
  }
  toggleDropdown(): void {
    this.showDropdown = !this.showDropdown;
  }
 
  confirmLogout(): void {
    this.showLogoutPopup = false;
    this.authservice.logout();
    this.router.navigate(['/login']);
  }
 
  cancelLogout(): void {
    this.showLogoutPopup = false;
  }
 
  logout(): void {
    this.showLogoutPopup = true;
    
  }
  isChildRouteActive():boolean{
    return this.router.url.startsWith('/adminaddservice') || this.router.url.startsWith('/adminviewservice');
  }

}
