import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Appointment } from 'src/app/models/appointment.model';
import { Feedback } from 'src/app/models/feedback.model';
import { AppointmentService } from 'src/app/services/appointment.service';
import { AuthService } from 'src/app/services/auth.service';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-useraddfeedback',
  templateUrl: './useraddfeedback.component.html',
  styleUrls: ['./useraddfeedback.component.css']
})
export class UseraddfeedbackComponent implements OnInit {

  userId:number
  feedback:Feedback={
    userId: 0,
    message: '',
    rating: 0,
    id: 0
  }
  listofAppointments:any=[]
  errorMsg=null
  addFeedback:boolean=false
  isLoading=false
  editingAppointmentId:number
  editingAppointment:any
  constructor(private service:FeedbackService,private router:Router,private authService:AuthService,private toastr:ToastrService,private appointment:AppointmentService) {
    this.userId=this.authService.getAuthenticatedUserId()
   }

  ngOnInit(): void {
    if(!this.authService.isUserLoggedIn())
    this.router.navigate(['/home'])

    this.isLoading=true
    this.appointment.getAppointmentsByUser(this.userId).subscribe({
      next:(data)=>
      {
        console.log(data.data)
        console.log(Array.isArray(data.data))
        this.listofAppointments=data.data.filter((da)=>
          da.status.trim().toLowerCase()==='completed' && !da.feedbackcompleted
  )
        console.log(this.listofAppointments);
        this.isLoading=false
      },
      error:(err)=>
      {
        this.toastr.error(err);
        this.isLoading=false
      }
    })
  }

  stars = Array(5).fill(0); 

  setRating(rating: number) {
    this.feedback.rating = rating;
  }

  submitFeedback() {
    if(this.feedback.rating<1){
      this.toastr.error("Rating cannot be lower than 1")
      return
    }
    if(this.feedback.rating>5){
     this.toastr.error("Rating cannot be higher than 5")
      return
    }
    this.errorMsg=null
    this.feedback.userId=this.userId
    this.isLoading=true
    this.service.createFeedback(this.feedback).subscribe({
      next: (data) => {
        console.log(data);
        this.addFeedbackchange(this.editingAppointmentId);
        this.feedback.message = '';
        this.feedback.rating = 0;
        this.addFeedback=false;
        this.toastr.success("Feedback addedd successfully!!!")
        this.router.navigate(['/userviewFeedbacks']);
        this.isLoading=false
      },
      error: (err) => {
        console.error('Error occurred:', err);
        this.toastr.error(err.error);
        // Navigate to appropriate error page based on status code
        // if (err.status === 0) {
        //   this.router.navigate(['/error/network']);
        // } else if (err.status === 401) {
        //   this.router.navigate(['/error/401']);
        // } else if (err.status === 403) {
        //   this.router.navigate(['/error/403']);
        // } else if (err.status === 500) {
        //   this.router.navigate(['/error/500']);
        // } else {
        //   this.router.navigate(['/error/404']);
        // }
      }
    });
  }

  addFeedbackchange(appointmentId:number)
  {

    let appointmentRequest={
      appointmentDate:'',
      location:'',
      userId:0,
      id:0,
      feedbackcompleted:false,
      status:''
    }
    let appointment=this.listofAppointments.filter((appo)=>appo.appointmentId===appointmentId);
    appointment[0].feedbackcompleted=true;
    appointmentRequest.appointmentDate=appointment[0].appointmentDate;
    appointmentRequest.location=appointment[0].location
    appointmentRequest.userId=this.userId;
    appointmentRequest.id=this.feedback.id
    appointmentRequest.status=appointment[0].status
    appointmentRequest.feedbackcompleted=true
    console.log(appointmentRequest);
    this.appointment.updateAppointment(appointmentId,appointmentRequest).subscribe((data)=>{
      console.log(data)
    },(error)=>
    {
      console.log(error);
    }
    )
  }
  getAppointmentId(id:number,serviceId:number)
  {
    this.editingAppointmentId=id;
    console.log(this.editingAppointmentId);
    this.feedback.id=serviceId;
    this.addFeedback=true
  }
  closeDialog()
  {
    this.addFeedback=false;
  }
  }