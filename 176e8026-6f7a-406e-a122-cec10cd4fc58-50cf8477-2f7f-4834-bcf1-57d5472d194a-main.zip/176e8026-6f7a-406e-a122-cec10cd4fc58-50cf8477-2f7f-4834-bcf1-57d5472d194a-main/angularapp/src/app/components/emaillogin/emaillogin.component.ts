import { Component, ElementRef, OnInit, QueryList, ViewChildren } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-emaillogin',
  templateUrl: './emaillogin.component.html',
  styleUrls: ['./emaillogin.component.css']
})
export class EmailloginComponent implements OnInit {

  email: string = '';
  otpSent = false;
  otpDigits: string[] = ['', '', '', '']; // 4-digit OTP
  isTimeGone=false;
  isLoading=false;

  @ViewChildren('otpInput') otpInputs!: QueryList<ElementRef>;

  constructor(private authService:AuthService, private router: Router,private toastr:ToastrService) {}

  sendOtp(form: NgForm) {
    if (form.valid) {
      this.isLoading=true
      this.authService.loginWithEmail(this.email).subscribe((data)=>
      {
        console.log(data);
        this.toastr.success(data.message)
        this.otpSent=true
        this.isLoading=false
      },(error)=>
      {
        this.isLoading=false
        this.toastr.error(error.error.message)
        console.log(error.error.message);
      })
    }
  }
  resendOtp(){
    this.isLoading=true
    this.authService.loginWithEmail(this.email).subscribe((data)=>
      {
        console.log(data);
        this.toastr.success(data.message)
        this.otpSent=true
        this.isLoading=false
      },(error)=>
      {
        this.isLoading=false
        this.toastr.error(error.error.message)
        console.log(error.error.message);
      })
  }
  
trackByIndex(index: number): number {
  return index;
}

onOtpInput(event: any, index: number) {
  const value = event.target.value;
  if (value && index < this.otpDigits.length - 1) {
    const next = document.querySelectorAll<HTMLInputElement>('.otp-input')[index + 1];
    next?.focus();
  }
}

onOtpBackspace(event: KeyboardEvent, index: number) {
  if (!this.otpDigits[index] && index > 0) {
    const prev = document.querySelectorAll<HTMLInputElement>('.otp-input')[index - 1];
    prev?.focus();
  }
}


  verifyOtp() {
    const isValid = this.otpDigits.every(d => d && d.trim() !== '');
    if (isValid) {
      this.isLoading=true
      this.authService.verifyOtp({
        email: this.email,
        otp: this.otpDigits.join('')
      }).subscribe({
        next: (data) => {
          localStorage.setItem('userId', "" + data.userId);
    localStorage.setItem('userRole', data.userRole);
    localStorage.setItem('username', data.username);
    localStorage.setItem('token',`Bearer ${data.token}`);
   // console.log(data.createdAt);
    localStorage.setItem('createdAt',data.createdAt)
    this.authService.isLoggedInSubject.next(true);
          this.toastr.success('Logged In Successfully!');
          this.router.navigate(['/home']);
          this.isLoading=false
        },
        error: (er) => {
          console.log(er.error.message)
        this.isLoading=false
          this.toastr.error(er.error.message);
        }
      });
    } else {
        this.isLoading=false
        this.toastr.error('Please enter all OTP digits');
    }
  }
  ngOnInit() {
    setTimeout(() => {
      this.isTimeGone = true;
      console.log('2 minutes passed, isTimeGone:', this.isTimeGone);
    }, 2*60*1000);
  }
  

}
