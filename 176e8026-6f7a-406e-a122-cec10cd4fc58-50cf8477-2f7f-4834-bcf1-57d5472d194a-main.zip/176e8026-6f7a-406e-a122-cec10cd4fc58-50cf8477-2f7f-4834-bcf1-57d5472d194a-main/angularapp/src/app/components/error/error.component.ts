import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements OnInit {

  errorCode: number = 0;
  message: string = '';
  showRetry: boolean = false;

  constructor(private route: ActivatedRoute) {
    this.route.data.subscribe(data => {
      this.errorCode = data['errorCode'];
      this.message = data['message'];
      this.showRetry = data['showRetry'] || false;
    });
  }

  getTitle(): string {
    switch (this.errorCode) {
      case 404: return 'Page Not Found';
      case 403: return 'Access Denied';
      case 500: return 'Internal Server Error';
      case 401: return 'Unauthorized';
      case 409: return 'User Already Exists';
      case 0:   return 'Network Error';
      default:  return 'Error';
    }
  }

  retry(): void {
    window.location.reload();
  }

  ngOnInit(): void {
  }

}