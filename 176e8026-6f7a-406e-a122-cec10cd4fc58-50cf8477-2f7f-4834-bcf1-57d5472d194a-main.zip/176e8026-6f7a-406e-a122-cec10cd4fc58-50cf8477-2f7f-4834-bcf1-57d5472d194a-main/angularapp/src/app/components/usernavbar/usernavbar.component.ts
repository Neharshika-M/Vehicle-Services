import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-usernavbar',
  templateUrl: './usernavbar.component.html',
  styleUrls: ['./usernavbar.component.css']
})
export class UsernavbarComponent implements OnInit {

  showDropdown1 = false;
  showDropdown2 = false;
  showLogoutPopup = false;
  isLoggedIn = false;
  username:string='';
  constructor(private authservice:AuthService,private router:Router) { }

  ngOnInit(): void 
  {
    this.getusername();
  }
  getusername()
  {
  this.username=this.authservice.getUsername();
  }
  toggleDropdown1(): void {
    console.log("enter");
    this.showDropdown1 = !this.showDropdown1;
    this.showDropdown2=false;
  }
  toggleDropdown2(): void {
    console.log("enter");
    this.showDropdown2 = !this.showDropdown2;
    this.showDropdown1=false;
  }
 
  confirmLogout(): void {
    this.showLogoutPopup = false;
    this.authservice.logout();
    this.router.navigate(['/login']);
  }
 
  cancelLogout(): void {
    this.showLogoutPopup = false;
  }
 
  logout(): void {
    this.showLogoutPopup = true;
    
  }
  isChildRouteActive1():boolean{
    return this.router.url.startsWith('/useraddappointment') || this.router.url.startsWith('/userviewappointment');
  }
  isChildRouteActive2():boolean{
    return this.router.url.startsWith('/addFeedback') || this.router.url.startsWith('/userviewFeedbacks');
  }

}
