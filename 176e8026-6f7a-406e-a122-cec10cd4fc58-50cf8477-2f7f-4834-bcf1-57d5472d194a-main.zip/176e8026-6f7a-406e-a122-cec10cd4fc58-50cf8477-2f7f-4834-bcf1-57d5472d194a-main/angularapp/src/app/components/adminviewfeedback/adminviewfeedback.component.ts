import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { FeedbackService } from 'src/app/services/feedback.service';
import { UserdetailsService } from 'src/app/services/userdetails.service';

@Component({
  selector: 'app-adminviewfeedback',
  templateUrl: './adminviewfeedback.component.html',
  styleUrls: ['./adminviewfeedback.component.css']
})
export class AdminviewfeedbackComponent implements OnInit {

  feedbackList:Feedback[]=[]
  selectedUser: User | null = null;
  isLoading=false
  constructor(private service:FeedbackService,private router:Router,private userService:UserdetailsService,private authService:AuthService) { }

  ngOnInit(): void {
    if(!this.authService.isUserLoggedIn())
    this.router.navigate(['/home'])
  this.isLoading=true
    this.service.getAllFeedbacks().subscribe({
      next: (data) => {
        this.feedbackList = data;
        console.log(this.feedbackList.length);
        this.isLoading=false
      },
      error: (err) => {
        this.isLoading=false
        console.error('Error loading feedbacks:', err);
        this.handleError(err.status);
      }
    });
    
  }
  handleError(status: number): void {
    if (status === 0) {
      this.router.navigate(['/error/network']);
    } else if (status === 401) {
      this.router.navigate(['/error/401']);
    } else if (status === 403) {
      this.router.navigate(['/error/403']);
    } else if (status === 500) {
      this.router.navigate(['/error/500']);
    } else {
      this.router.navigate(['/error/404']);
    }
  }

  showProfile(user:User){
    this.selectedUser=user
  }
  closePopup(){
    this.selectedUser=null
  }
}
