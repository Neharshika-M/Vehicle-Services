import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import {ToastrService} from 'ngx-toastr';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username = '';
  password = '';
  submitted = false;
  invalidLogin = false;
  successMessageVisible: boolean = false;
  showPassword:boolean=false
  isLoading=false

  constructor(private authService:AuthService,private router:Router,private toastr:ToastrService) {}

  onSubmit(form: NgForm): void {
    this.submitted = true;
    this.invalidLogin = false;
    this.successMessageVisible = true;
    if (form.invalid) return;
  
    this.username=form.value.username
    this.password=form.value.password
    this.isLoading=true
    this.authService.login(this.username, this.password).subscribe({
      next: (response) => {
       // alert('Login successful');
        this.toastr.success("LoggedIn successfully!")
        this.router.navigate(['/home'])
        this.isLoading=false
      },
      error: (err) => {
        // console.error(err);
        // if(err.status===500||err.status===0)
        // {
        //   this.toastr.error("Server is not connected!!!")
        //   this.handleError(err.error.status);
        // }
        // if(err.status===403||err.status===409)
        // {
        //   this.toastr.error(err.error.message);
        // }
        // //this.handleError(err.status);
        console.log(err.error);
        this.isLoading=false
        this.toastr.error(err.error.message);
      }
    });
  }
  
  ngOnInit(): void {
    if(this.authService.hasToken()){
      this.router.navigate(['/home'])
    }
  }
  togglePasswordVisibility(){
    this.showPassword=!this.showPassword
  }

}

