import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Appointment } from 'src/app/models/appointment.model';
import { VehicleMaintenance } from 'src/app/models/vehicle-maintenance.model';
import { AppointmentService } from 'src/app/services/appointment.service';
import { AuthService } from 'src/app/services/auth.service';
import { VehicleService } from 'src/app/services/vehicle.service';

@Component({
  selector: 'app-adminviewservice',
  templateUrl: './adminviewservice.component.html',
  styleUrls: ['./adminviewservice.component.css']
})
export class AdminviewserviceComponent implements OnInit {
  services: VehicleMaintenance[] = [];
  searchText: string = '';
  page = 1;
  pageSize = 5;
  editing = false;
  deleting = false;
  successMessageVisible = false;
  successMessageText = '';
  selected: VehicleMaintenance | null = null;
  showAll = false; // Initialize showAll to false for paginated view by default
  vehicleTypes:string[]=[]; //unique types fetched from services
  selectedVehicleType:string='';
  isLoading=false;

  constructor(private vehicleService: VehicleService,private router:Router,private authService:AuthService,private toastr:ToastrService) {}

  ngOnInit(): void {
    if(!this.authService.isUserLoggedIn())
    this.router.navigate(['/home'])
    this.loadServices();
  }

  loading = false;

loadServices(): void {
  this.loading = true;
  const trimmedName = this.searchText.trim();

  const request$ = trimmedName
    ? this.vehicleService.getServiceByName(trimmedName)
    : this.vehicleService.getAllServices();

  request$.subscribe({
    next: (data: VehicleMaintenance[]) => {
      this.services = data;
      this.vehicleTypes=Array.from(new Set(data.map(s=>s.typeOfVehicle)));
      if (!this.showAll) {
        this.page = 1;
      }
    },
    error: (err) => {
      this.isLoading=false
      console.error('Error fetching services:', err);

      // Only navigate for critical errors
      if ([0, 401, 403, 500].includes(err.status)) {
        this.handleError(err.status);
      } else {
        this.toastr.error("Unable to load services. Please try again.");
      }
    },
    complete: ()=>{
      this.loading = false;
    }})};
    
get filteredServices():VehicleMaintenance[]
{
  let result=this.services;
  if(this.searchText)
  {
    result=result.filter(s=>s.serviceName.toLowerCase().includes(this.searchText.toLowerCase()));
  }
  if(this.selectedVehicleType)
  {
    result=result.filter(s=>s.typeOfVehicle===this.selectedVehicleType);
  }
  return result;
}
  get paginatedServices(): VehicleMaintenance[] {
    const filtered=this.filteredServices;
    if (this.showAll) {
      return filtered;
    }
    const startIndex = (this.page - 1) * this.pageSize;
    return filtered.slice(startIndex, startIndex + this.pageSize);
  }
onTypeChange()
{
  this.page=1;
}
  totalPages(): number {
    return Math.ceil(this.services.length / this.pageSize);
  }

  goToPage(p: number) {
    if (p >= 1 && p <= this.totalPages()) {
      this.page = p;
    }
  }

 
  toggleView() {
    this.showAll = !this.showAll;
    this.searchText = ''; 
    this.loadServices(); 
  }


  openEdit(service: VehicleMaintenance) {
    console.log(this.selected);
    this.selected = { ...service };
    console.log(this.selected);
    this.editing = true;
  }

  saveEdit() {
    if (!this.selected) return;
    console.log(this.selected.id);
    this.isLoading=true
    this.vehicleService.updateService(this.selected.id, this.selected).subscribe({
      next: () => {
        this.successMessageText = 'Data updated successfully!';
        this.successMessageVisible = true;
        this.loadServices();
        this.closePopup();
        this.isLoading=false
      },
      error: (err) => {
        this.isLoading=false
        console.error('Error updating service:', err);
        this.handleError(err.status);
      }
    });
  }

  openDelete(service: VehicleMaintenance) {
    this.selected = service;
    this.deleting = true;
  }

  confirmDelete() {
    if (!this.selected) return;
    this.isLoading=true
    this.vehicleService.deleteService(this.selected.id).subscribe({
      next: () => {
        this.successMessageText = 'Service deleted successfully!';
        this.successMessageVisible = true;
        this.loadServices();
        this.closePopup();
        this.isLoading=false
      },
      error: (err) => {
        this.isLoading=false
        console.error('Error deleting service:', err);
        this.handleError(err.status);
      }
    });
  }

  closePopup() {
    this.editing = false;
    this.deleting = false;
    this.selected = null;
  }

  closeSuccessModal() {
    this.successMessageVisible = false;
  }
  

  handleError(status: number): void {
    if (status === 0) {
      this.router.navigate(['/error/network']);
    } else if (status === 401) {
      this.router.navigate(['/error/401']);
    } else if (status === 403) {
      this.router.navigate(['/error/403']);
    } else if (status === 500) {
      this.router.navigate(['/error/500']);
    } else {
      this.router.navigate(['/error/404']);
    }
  }
}
