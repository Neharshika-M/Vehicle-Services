import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Appointment } from 'src/app/models/appointment.model';
import { AppointmentService } from 'src/app/services/appointment.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-adminviewappointment',
  templateUrl: './adminviewappointment.component.html',
  styleUrls: ['./adminviewappointment.component.css']
})
export class AdminviewappointmentComponent implements OnInit {

  appointments = [];
  filteredAppointments=[]
  vehicleLocation=[]
  selectedAppointmentId: number | null = null;
  showDeletePopup: boolean = false;
  isLoading=false
  byServiceName:boolean=false;
  byVehicleType:boolean=false;
  byUsername:boolean=false;
  filterSelected:boolean=false;
  searchText:string;
  page = 1;
  pageSize = 5;
  constructor(private appointmentService: AppointmentService,private router:Router,private authService:AuthService,private tostr:ToastrService) {}

  ngOnInit(): void {
    if(!this.authService.isUserLoggedIn())
    this.router.navigate(['/home'])
    this.loadAppointments();
  }

  loadAppointments(): void {
    this.isLoading=true
    this.appointmentService.getAppointments().subscribe({
      next: (data) => {
        console.log(data)
        this.appointments = data.data;
        this.filteredAppointments=this.appointments;
        this.vehicleLocation=Array.from(new Set(this.appointments.map(s=>s.location)));
        console.log(this.appointments);
        this.isLoading=false
      },
      error: (err) => {
        this.isLoading=false
        console.error('Error loading appointments:', err);
        this.handleError(err.status);
      }
    });
  }
  

  updateStatus(appointment: any, newStatus: string): void {
    console.log(appointment);
    const updatedAppointment = { appointmentDate:appointment.appointmentDate,location:appointment.location,status: newStatus ,userId:appointment.user.userId,id:appointment.vehicleMaintenance.id};
    console.log(updatedAppointment)
    this.appointmentService.updateAppointment(appointment.appointmentId!, updatedAppointment)
      .subscribe({
        next: () => {
          appointment.status = newStatus;
          this.tostr.success("Appointment "+newStatus);
        },
        error: (err) => {
          console.error('Error updating status:', err);
          this.handleError(err.status);
          this.tostr.error("error occured")
        }
      });
  }
  confirmDelete(appointmentId: number): void {
    this.selectedAppointmentId = appointmentId;
    this.showDeletePopup = true;
  }
  
  cancelDelete(): void {
    this.selectedAppointmentId = null;
    this.showDeletePopup = false;
  }
  
  proceedDelete(): void {
    if (this.selectedAppointmentId !== null) {
      this.appointmentService.deleteAppointment(this.selectedAppointmentId).subscribe({
        next: () => {
          this.appointments = this.appointments.filter(a => a.appointmentId !== this.selectedAppointmentId);
          this.showDeletePopup = false;
          this.selectedAppointmentId = null;
        },
        error: (err) => {
          console.error('Error deleting appointment:', err);
          this.showDeletePopup = false;
          this.selectedAppointmentId = null;
          this.handleError(err.status);
        }
      });
    }
  }
// Method to get a subset of filtered appointments for the current page
get paginatedAppointments(): Appointment[] {
  const startIndex = (this.page - 1) * this.pageSize;
  return this.filteredAppointments.slice(startIndex, startIndex + this.pageSize);
}

// Method to calculate the total number of pages
totalPages(): number {
  return Math.ceil(this.filteredAppointments.length / this.pageSize);
}

// Method to navigate to a specific page
goToPage(p: number) {
  if (p >= 1 && p <= this.totalPages()) {
    this.page = p;
  }
}
  handleError(status: number): void {
    if (status === 0) {
      this.router.navigate(['/error/network']);
    } else if (status === 401) {
      this.router.navigate(['/error/401']);
    } else if (status === 403) {
      this.router.navigate(['/error/403']);
    } else if (status === 500) {
      this.router.navigate(['/error/500']);
    } else {
      this.router.navigate(['/error/404']);
    }
  }
  applyFilter()
  {
    if(this.byServiceName)
    {
      console.log("into service name")
      this.filterByServiceName();
    }
    if(this.byVehicleType)
    {
      console.log("into vehicle type")
      this.filterByVehicleType();
    }
    if(this.byUsername)
    {
      console.log("into user name")
      this.filterByUsername()
    }
  }
  filterByServiceName()
  {
    if(this.searchText==="")
      this.filteredAppointments=this.appointments;
    this.filteredAppointments=this.appointments.filter((appointment)=>appointment.vehicleMaintenance.serviceName.toLowerCase().includes(this.searchText));
  }
  filterByVehicleType()
  {
    if(this.searchText==="")
    this.filteredAppointments=this.appointments;
    this.filteredAppointments=this.appointments.filter((appointment)=>appointment.vehicleMaintenance.typeOfVehicle.toLowerCase().includes(this.searchText));
  }
  filterByUsername()
  {
    if(this.searchText==="")
    this.filteredAppointments=this.appointments;
    this.filteredAppointments=this.appointments.filter((appointment)=>appointment.user.username.toLowerCase().includes(this.searchText));
  }
  filterByLocation(loc:string){
    this.filteredAppointments=this.appointments.filter((appointment)=>appointment.location==loc);
  }
  selectChangeType(event:any)
  {
    this.filterSelected=true;
    console.log(event);
    if(event==="")
    {
      this.resetFilter()
    }
    if(event==="By Service Name")
    {
      this.byUsername=false;
    this.byVehicleType=false;
    this.byServiceName=!this.byServiceName;
    }
    if(event==="By Vehicle Type")
    {
      this.byUsername=false;
      this.byServiceName=false;
      this.byVehicleType=!this.byVehicleType;
    }
    if(event==="By User name")
    {
      this.byVehicleType=false;
      this.byServiceName=false;
      this.byUsername=!this.byUsername;
    }
  }
  resetFilter()
  {
    this.filteredAppointments=this.appointments;
    this.searchText="";
    this.filterSelected=false;
   const element= document.getElementById("select") as HTMLInputElement;
   element.value=""
  }
}