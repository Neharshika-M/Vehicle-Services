import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
 user:User={
  email:'',
    password:'',
    username:'',
    mobileNumber:'',
    userRole:''
 };

 confirmPassword=''
  errorMessage = '';
  successMessageVisible: boolean = false;
  showPassword:boolean=false;
  isLoading=false
  isMailError=false
  submitted=false
  constructor(private authService: AuthService,private router:Router,private toastr:ToastrService) { }
  ngOnInit(): void {
    if(this.authService.hasToken()){
      this.router.navigate(['/home'])
    }
  }
  register(registrationForm:NgForm)
  {
    this.submitted=true;
    if(registrationForm.valid)
    {
      this.isLoading=true
      this.user=registrationForm.value
      this.successMessageVisible = true;
      if(!(registrationForm.value.email+''.includes("@gmail.com"))||!(registrationForm.value.email+''.includes("@email.com")))
      {
        console.log("into the email valid")
        this.isMailError=true;
        return;
      }
    this.authService.addUser(this.user).subscribe({
      next:(data)=>{
        this.toastr.success("Registartion Successfull!")
        this.router.navigate(['/login'])
        this.isLoading=false
      },
      error:(err)=>{
        console.log(err.error)
        this.isLoading=false
        this.toastr.error(err.error.message)
        //this.handleError(err)
      }
    })
  }

}
togglePasswordVisibility(){
  this.showPassword=!this.showPassword
}
private handleError(err: any) {
  if (err.status === 404) {
    this.router.navigate(['/error/404']);
  } else if (err.status === 403) {
    this.router.navigate(['/error/403']);
  } else if (err.status === 401) {
    this.router.navigate(['/error/401']);
  } else if (err.status === 409) {
    this.router.navigate(['/error/409']);
  } else if (err.status === 0) {
    this.router.navigate(['/error/network']);
  } else {
    this.router.navigate(['/error/500']);
  }
}
closeModal() {
  this.successMessageVisible = false;
}
}