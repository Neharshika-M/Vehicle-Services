import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { UserdetailsService } from 'src/app/services/userdetails.service';

@Component({
  selector: 'app-adminviewuserdetails',
  templateUrl: './adminviewuserdetails.component.html',
  styleUrls: ['./adminviewuserdetails.component.css']
})
export class AdminviewuserdetailsComponent implements OnInit {

  users: User[] = [];
  selectedUser: User | null = null;
  searchTerm: string = '';
  userNotFound: boolean = false;
  showDeletePopup:boolean=false
  selectedUserId:number | null = null;
  isLoading=false
  filteredUsers=[]
  constructor(private userService: UserdetailsService,private router:Router,private authService:AuthService) {}

  ngOnInit(): void {
    if(!this.authService.isUserLoggedIn())
    this.router.navigate(['/home'])
  this.isLoading=true
    this.userService.findAllUsers().subscribe((data: User[]) => {
      this.users = data.filter(user => user.userRole === 'USER');
      this.filteredUsers=this.users;
      this.isLoading=false
    });
  }

  selectUser(user: User): void {
    this.selectedUser = user;
    this.userNotFound = false;
  }

  searchUser(): void {
    if(this.searchTerm==="")
    {
      this.filteredUsers=this.users;
    }
    this.filteredUsers=this.users.filter((user)=>user.username.toLowerCase().includes(this.searchTerm));
  }

  deleteUser(id: number): void {
    this.isLoading=true
    this.userService.deleteUser(id).subscribe(() => {
      this.users = this.users.filter(user => user.userId !== id);
      this.isLoading=false
    });
  }
  closePopup(){
    this.selectedUser=null
    this.userNotFound=false
  }
  confirmDelete(id: number): void {
    this.selectedUserId=id
    this.showDeletePopup=true
  }
  
  cancelDelete(): void {
    this.selectedUserId = null;
    this.showDeletePopup = false;
  }
  
  proceedDelete(): void {
    if (this.selectedUserId !== null) {
      this.isLoading=true
      this.userService.deleteUser(this.selectedUserId).subscribe(() => {
        this.users = this.users.filter(user => user.userId !== this.selectedUserId);
        this.showDeletePopup = false;
          this.selectedUserId = null;
          this.isLoading=false
      });
    }
  }
}