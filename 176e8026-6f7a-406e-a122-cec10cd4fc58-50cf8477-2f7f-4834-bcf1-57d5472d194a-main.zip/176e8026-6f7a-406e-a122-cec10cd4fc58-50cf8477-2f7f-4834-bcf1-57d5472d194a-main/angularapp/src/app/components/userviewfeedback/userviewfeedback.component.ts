import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Appointment } from 'src/app/models/appointment.model';
import { Feedback } from 'src/app/models/feedback.model';
import { AppointmentService } from 'src/app/services/appointment.service';
import { AuthService } from 'src/app/services/auth.service';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-userviewfeedback',
  templateUrl: './userviewfeedback.component.html',
  styleUrls: ['./userviewfeedback.component.css']
})
export class UserviewfeedbackComponent implements OnInit {

  feedbackList: Feedback[] = [];
  userId = 1;
  showPopup = false;
  appointmentsbyUserid=[]
  selectedFeedbackId?: number;
  isLoading=false


  showEditPopup = false;
  editableFeedback: any ={
    userId: 0,
    message: '',
    rating: 0,
    id: 0
  }
  feedbackId:number
  stars = Array(5).fill(0);

  EditFeedback1(feedback:any) {
    console.log(feedback);
    this.feedbackId=feedback.feedbackId;
        this.editableFeedback = {
          userId:feedback.user.userId,
          message:feedback.message,
          rating:feedback.rating,
          id:feedback.vehicleMaintenance.id,
        };
        this.showEditPopup = true;
  }

  setEditRating(rating: number) {
    this.editableFeedback.rating = rating;
  }

  cancelEdit() {
    this.showEditPopup = false;
    this.editableFeedback={
      userId: 0,
      message: '',
      rating: 0,
      id: 0
    }
  }

  saveEdit() {
    this.isLoading = true;

    this.service.updateFeedback(this.feedbackId, this.editableFeedback).subscribe({
      next: (data) => {
        console.log(data);
        this.showEditPopup = false;
        this.loadFeedback();
        this.isLoading = false;
        this.toastr.success("Feedback updated successfully");
      },
      error: (err) => {
        console.log(err)
        this.isLoading = false;
        console.error('Error updating feedback:', err);
        this.handleError(err);
      }
    });
  }

  constructor(
    private service: FeedbackService,
    private router: Router,
    private authService:AuthService,
    private toastr:ToastrService,
    private appointment:AppointmentService
  ) {
    this.userId=this.authService.getAuthenticatedUserId()
    console.log(authService.isUserLoggedIn())
   }

  ngOnInit(): void {
    if(!this.authService.isUserLoggedIn())
    {
       this.router.navigate(['/home'])
       this.toastr.error("Session expired please login")
    }
    this.loadFeedback();
  }

  openConfirmPopup(feedbackId: number) {
    this.selectedFeedbackId = feedbackId;
    this.showPopup = true;
  }

  cancelDelete() {
    this.showPopup = false;
    this.selectedFeedbackId = undefined;
  }

  confirmDelete() {
    if (this.selectedFeedbackId) {
      this.isLoading=true
      this.service.deleteFeedback(this.selectedFeedbackId).subscribe({
        next: () => {
          console.log("Feedback deleted");
          //To close popup
          this.showPopup = false;
        this.isLoading=false
        this.loadFeedback();
          // this.cancelDelete(); // Close popup
        },
        error: (err) => {
        this.isLoading=false
        console.error('Error deleting feedback:', err);
          this.handleError(err);
        }
      });
    }
  }

  loadFeedback() {
    this.isLoading=true
    this.service.getAllFeedbacksbyUserId(this.userId).subscribe({
      next: (data) => {
        console.log(data);
        this.feedbackList = data;
        this.isLoading=false
      },
      error: (err) => {
        this.isLoading=false
        console.error('Error loading feedback:', err);
        this.handleError(err);
      }
    });
    this.appointment.getAppointmentsByUser(this.userId).subscribe({
      next:(data)=>
      {
        console.log(data);
        this.appointment=data.data
        this.isLoading=false
      },error:(err)=>
      {
        console.log(err);
      }
    })
  }

  private handleError(err: any) {
    if (err.status === 404) {
      this.router.navigate(['/error/404']);
    } else if (err.status === 403) {
      this.router.navigate(['/error/403']);
    } else if (err.status === 401) {
      this.router.navigate(['/error/401']);
    } else if (err.status === 0) {
      this.router.navigate(['/error/network']);
    } else {
      this.router.navigate(['/error/500']);
    }
  }


}

