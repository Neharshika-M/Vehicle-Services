import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { VehicleMaintenance } from 'src/app/models/vehicle-maintenance.model';
import { AuthService } from 'src/app/services/auth.service';
import { VehicleService } from 'src/app/services/vehicle.service';

@Component({
  selector: 'app-adminaddservice',
  templateUrl: './adminaddservice.component.html',
  styleUrls: ['./adminaddservice.component.css']
})
export class AdminaddserviceComponent implements OnInit {

  VehicleMaintenance: VehicleMaintenance = {
    id: 0,
    serviceName: '',
    servicePrice: 0,
    typeOfVehicle: ''
  };

  successMessageVisible: boolean = false;


  constructor(private service: VehicleService,private router:Router,private authService:AuthService) {}

  ngOnInit(): void {
    if(!this.authService.isUserLoggedIn())
    this.router.navigate(['/home'])
  }

  addService(addServiceform: NgForm) {
    if (addServiceform.valid) {
      this.service.addService(this.VehicleMaintenance).subscribe({
        next: (data) => {
          console.log(data);
          this.successMessageVisible = true;
          addServiceform.resetForm();
          this.router.navigate(['/adminaddservice'])
        },
        error: (err) => {
          console.error('Error occurred:', err);
  
          // Navigate to appropriate error page based on status code
          if (err.status === 0) {
            this.router.navigate(['/error/network']);
          } else if (err.status === 401) {
            this.router.navigate(['/error/401']);
          } else if (err.status === 403) {
            this.router.navigate(['/error/403']);
          } else if (err.status === 500) {
            this.router.navigate(['/error/500']);
          } else {
            this.router.navigate(['/error/404']);
          }
        }
      });
    }
  }

  closeModal() {
    this.successMessageVisible = false;
  }
}