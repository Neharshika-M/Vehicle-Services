import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentService } from 'src/app/services/appointment.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-userviewappointment',
  templateUrl: './userviewappointment.component.html',
  styleUrls: ['./userviewappointment.component.css']
})
export class UserviewappointmentComponent implements OnInit {

  appointments: any = [];
  filteredAppointments: any = [];
  selectedStatus: string = 'All';
  userId = 1;
  isLoading = false;
  
  // Pagination properties
  page: number = 1; // The current page number
  pageSize: number = 5; // The number of items per page
  
  constructor(
    private appointmentService: AppointmentService,
    private router: Router,
    private authService: AuthService
  ) {
    this.userId = this.authService.getAuthenticatedUserId();
    console.log(authService.isUserLoggedIn());
  }

  ngOnInit(): void {
    if (!this.authService.isUserLoggedIn()) {
      this.router.navigate(['/home']);
    }
    this.loadAppointments();
  }

  loadAppointments(): void {
    this.isLoading = true;
    this.appointmentService.getAppointmentsByUser(this.userId).subscribe({
      next: (data) => {
        console.log(data.data);
        this.appointments = data.data;
        this.applyFilter(); // Apply filter and set initial pagination
        this.isLoading = false;
      },
      error: (err) => {
        this.isLoading = false;
        console.error('Error fetching appointments:', err);

        if (err.status === 404) {
          this.router.navigate(['/error/404']);
        } else if (err.status === 403) {
          this.router.navigate(['/error/403']);
        } else if (err.status === 401) {
          this.router.navigate(['/error/401']);
        } else if (err.status === 0) {
          this.router.navigate(['/error/network']);
        } else {
          this.router.navigate(['/error/500']);
        }
      }
    });
  }

  applyFilter(): void {
    // Reset page to 1 whenever a filter is applied
    this.page = 1;

    if (this.selectedStatus === 'All') {
      this.filteredAppointments = this.appointments;
    } else {
      this.filteredAppointments = this.appointments.filter(
        appt => appt.status === this.selectedStatus
      );
    }
  }
  
  // Getter to provide the paginated version of the filtered appointments
  get paginatedAppointments(): any[] {
    const startIndex = (this.page - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    return this.filteredAppointments.slice(startIndex, endIndex);
  }

  // Calculate the total number of pages
  totalPages(): number {
    return Math.ceil(this.filteredAppointments.length / this.pageSize);
  }

  // Change to a specific page
  goToPage(p: number): void {
    if (p >= 1 && p <= this.totalPages()) {
      this.page = p;
    }
  }
  
  // Method to check if the current page is the first page
  isFirstPage(): boolean {
    return this.page === 1;
  }
  
  // Method to check if the current page is the last page
  isLastPage(): boolean {
    return this.page === this.totalPages();
  }
}
