import { Injectable } from '@angular/core';
import { Feedback } from '../models/feedback.model';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { env } from 'process';
@Injectable({
  providedIn: 'root'
})
export class FeedbackService {

  apiUrl=environment.apiUrl+'api/feedback'
  constructor(private http:HttpClient) { }
  createFeedback(feedback:Feedback):Observable<Feedback>{
    return this.http.post<Feedback>(this.apiUrl,feedback);
  }
  getFeedbackById(feedbackId:number):Observable<Feedback>{
    return this.http.get<Feedback>(this.apiUrl+'/'+feedbackId);
  }
  deleteFeedback(feedbackId:number):Observable<void>{
    return this.http.delete<void>(this.apiUrl+'/'+feedbackId);
  }
  getAllFeedbacks():Observable<Feedback[]>{
    return this.http.get<Feedback[]>(this.apiUrl);
  }
  getAllFeedbacksbyUserId(userId:number):Observable<Feedback[]>{
    return this.http.get<Feedback[]>(this.apiUrl+'/user/'+userId);
  }
  updateFeedback(feedbackId:number,feedback:Feedback):Observable<Feedback>{
    return this.http.put<Feedback>(this.apiUrl+'/'+feedbackId,feedback);
  }

}

