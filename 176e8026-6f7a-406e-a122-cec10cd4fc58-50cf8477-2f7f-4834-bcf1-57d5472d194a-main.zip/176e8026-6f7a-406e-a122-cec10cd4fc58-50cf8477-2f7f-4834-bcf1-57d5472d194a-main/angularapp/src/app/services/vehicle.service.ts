import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { VehicleMaintenance } from '../models/vehicle-maintenance.model';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class VehicleService {
public apiUrl=environment.apiUrl+"api/services";
  constructor(private httpclient:HttpClient) { }
  getAllServices():Observable<VehicleMaintenance[]>
  {
    return this.httpclient.get<VehicleMaintenance[]>(this.apiUrl);
  }
  addService(service:VehicleMaintenance):Observable<VehicleMaintenance>
  {
    return this.httpclient.post<VehicleMaintenance>(this.apiUrl,service);
  }
  updateService(serviceId:number,service:VehicleMaintenance):Observable<VehicleMaintenance>
  {
    return this.httpclient.put<VehicleMaintenance>(this.apiUrl+"/"+serviceId,service);
  }
  deleteService(serviceid:number):Observable<void>
  {
    return this.httpclient.delete<void>(this.apiUrl+"/"+serviceid);
  }
  getServiceByName(serviceName: string): Observable<VehicleMaintenance[]> {
    return this.httpclient.get<VehicleMaintenance[]>(this.apiUrl + "/service?serviceName=" + serviceName);
  }
}
