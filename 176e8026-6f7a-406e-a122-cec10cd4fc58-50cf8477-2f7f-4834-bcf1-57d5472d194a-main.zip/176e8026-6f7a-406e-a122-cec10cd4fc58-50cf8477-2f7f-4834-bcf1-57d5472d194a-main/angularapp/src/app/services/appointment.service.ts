import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Appointment } from '../models/appointment.model';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class AppointmentService {

  apiUrl=environment.apiUrl+'api/appointment'
  constructor(private http:HttpClient) { }
  getAppointments():Observable<any>{
    return this.http.get<any>(this.apiUrl)
  }
  getAppointmentsByUser(userId:number):Observable<any>{
    return this.http.get<any>(this.apiUrl+'/'+userId);
  }
  addAppointment(appointment:Appointment):Observable<Appointment>{
    return this.http.post<Appointment>(this.apiUrl,appointment)
  }
  updateAppointment(appointmentId:number,appointment:any):Observable<any>{
    return this.http.put<any>(this.apiUrl+'/'+appointmentId,appointment)
  }
  deleteAppointment(appointmentId:number):Observable<void>{
    return this.http.delete<void>(this.apiUrl+'/'+appointmentId)
  }
  getAppointmentById(appointmentId:number):Observable<Appointment>{
    return this.http.get<Appointment>(this.apiUrl+'/get/'+appointmentId)
  }
}
