import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from '../models/user.model';
import { BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';
export class AuthenticationBean {

  constructor(
    public userId: number,
    public token: string,
    public userRole: string,
    public createdAt:string,
  ) {}

}

@Injectable({
  providedIn: 'root'
})

export class AuthService {

  APP_URL =environment.apiUrl +"api";

  public isLoggedInSubject = new BehaviorSubject <boolean> (this.hasToken());
  public isLoggedIn$ = this.isLoggedInSubject.asObservable();

  constructor(private http: HttpClient) {}

  // Register new user

  addUser(user: User): Observable<any>  {
    return this.http.post(`${this.APP_URL}/register` ,user,{headers:{'content-Type':'application/json'}});
  }

  loginWithEmail(email:string):Observable<any>{
    return this.http.post<any>(`${this.APP_URL}/email/login` , {email})
  }
  verifyOtp(email:any):Observable<any>{
    return this.http.post(`${this.APP_URL}/email/verify` , email)
  }
  verifyOtpForUpdate(email:any):Observable<any>{
    return this.http.post(`${this.APP_URL}/otp/verify` , email)
  }
  login(username: string, password: string): Observable<any> {
    return this.http.post<AuthenticationBean>( `${this.APP_URL}/login`  , { username, password }).pipe(
    map(data => {
    console.log(data)
    localStorage.setItem('userId', "" + data.userId);
    localStorage.setItem('userRole', data.userRole);
    localStorage.setItem('username', username);
    localStorage.setItem('token',`Bearer ${data.token}`);
   // console.log(data.createdAt);
    localStorage.setItem('createdAt',data.createdAt)
    this.isLoggedInSubject.next(true);
    return data;
    })
    );
  }


  getAuthenticatedUserId(): number {

    return parseInt(localStorage.getItem('userId') || '0');

  }

  getRole(): string | null {

    return localStorage.getItem('userRole');

  }

  getAuthenticatedUser(): string | null {

    return localStorage.getItem('username');

  }
  getCreatedAt()
  {
    return localStorage.getItem('createdAt');
  }

  getUsername(): string | null {

    return localStorage.getItem('username');

  }

  getAuthenticatedToken(): string | null {

    if (this.getAuthenticatedUser())

    return localStorage.getItem('token');

    return null;

  }

  isAdmin(): boolean {

    let role = localStorage.getItem('userRole');

    return role === 'ADMIN';

  }

  isCustomer(): boolean {

    let role = localStorage.getItem('userRole');

    return role === 'USER';

  }

  isUserLoggedIn(): boolean {

    let user = localStorage.getItem('username');

    return (!!user);

  }

  logout(): void {
    localStorage.clear()
    this.isLoggedInSubject.next(false);
  }

  hasToken(): boolean {

    return !!localStorage.getItem('token');
  }

}