package com.examly.springapp.service;

import java.time.Instant;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;

import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.stereotype.Service;

import com.examly.springapp.Dto.LoginRequestDTO;
import com.examly.springapp.Dto.LoginResponseDTO;
import com.examly.springapp.Exceptions.UserNotFoundException;
import com.examly.springapp.Exceptions.UsernameDuplicateException;
import com.examly.springapp.config.JwtUtils;
import com.examly.springapp.model.Errorlog;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.ErrorlogRepo;
import com.examly.springapp.repository.UserRepo;

import jakarta.mail.internet.MimeMessage;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    private UserRepo urepo;
    @Autowired 
    private PasswordEncoder passwordEncoder;
    @Autowired
    private JwtUtils jwtUtils;
    @Autowired
    private JavaMailSender javaMailSender;
    @Autowired
    private ErrorlogRepo lRepo;
    private void sendLoginSuccessEmail(User user) {
    try {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

        helper.setTo(user.getEmail());
        helper.setSubject("✅ Login Successful - " + user.getUsername());

        String htmlContent = "<!DOCTYPE html>" +
                "<html><head><style>" +
                "body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }" +
                ".container { background-color: #fff; padding: 20px; border-radius: 8px; max-width: 500px; margin: auto; }" +
                "h2 { color: #2c3e50; } p { color: #555; }" +
                "</style></head><body>" +
                "<div class='container'>" +
                "<h2>Hello " + user.getUsername() + ",</h2>" +
                "<p>You have successfully logged into your account on <strong>" + Instant.now().atZone(ZoneId.systemDefault()).toLocalDateTime() + "</strong>.</p>" +
                "<p>If this wasn’t you, please reset your password immediately.</p>" +
                "<br><p>Best regards,<br><strong>Vehicle Service</strong></p>" +
                "</div></body></html>";

        helper.setText(htmlContent, true);
        javaMailSender.send(mimeMessage);

    } catch (Exception e) {
        lRepo.save(new Errorlog("Error", "EMAILERROR", "409", "FAILED TO SEND MAIL", "USER Service",new Date()));
        System.out.println("Failed to send login email: " + e.getMessage());
    }
}
private void sendRegisterSuccessEmail(User user) {
    try {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

        helper.setTo(user.getEmail());
        helper.setSubject("✅ Register Successful - " + user.getUsername());

        String htmlContent = "<!DOCTYPE html>" +
                "<html><head><style>" +
                "body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }" +
                ".container { background-color: #fff; padding: 20px; border-radius: 8px; max-width: 500px; margin: auto; }" +
                "h2 { color: #2c3e50; } p { color: #555; }" +
                "</style></head><body>" +
                "<div class='container'>" +
                "<h2>Hello " + user.getUsername() + ",</h2>" +
                "<p>You have successfully Created your account on <strong>" + Instant.now().atZone(ZoneId.systemDefault()).toLocalDateTime() + "</strong>.</p>" +
                "<br><p>Best regards,<br><strong>Vehicle Service</strong></p>" +
                "</div></body></html>";

        helper.setText(htmlContent, true);
        javaMailSender.send(mimeMessage);

    } catch (Exception e) {
        System.out.println("Failed to send register email: " + e.getMessage());
    }
}
    @Override
    public User createUser(User user) {
        User user2=urepo.findByUsername(user.getUsername()).orElse(null);
        if(user2!=null)
        {
            lRepo.save(new Errorlog("Error", "USERERROR", "409", "USER ALREADY FOUND WITH SAME USERNA", "USER SERVICE",new Date()));
            throw new UsernameDuplicateException("User already found with same username.");
        }
        User user3=urepo.findByEmail(user.getEmail());
        if(user3!=null)
              {
                lRepo.save(new Errorlog("Error", "USERERROR", "409", "USER ALREADY FOUND WITH SAME EMAIL", "USER SERVICE",new Date()));
                  throw new UsernameDuplicateException("User already found with these same email please try login");
              }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        sendRegisterSuccessEmail(user);
            return urepo.save(user);
        
    }

    @Override
    public LoginResponseDTO loadUserByUsername(String userName,LoginRequestDTO requestDTO) {
        User user=urepo.findByUsername(userName).orElse(null);
        if(user==null)
        {
            lRepo.save(new Errorlog("Error", "USERERROR", "409", "USER NOT FOUND WITH USERNAME", "USER SERVICE",new Date()));
            throw new UserNotFoundException("User not found with username: "+userName);
        }
         if(passwordEncoder.matches(requestDTO.getPassword(),user.getPassword()))
        {
            sendLoginSuccessEmail(user);
            return new LoginResponseDTO(user.getUsername(),jwtUtils.generateToken(user.getUsername()), user.getUserRole(),user.getUserId(),Instant.now().toEpochMilli());
        }
        lRepo.save(new Errorlog("Error", "USERERROR", "409", "USER PROVIDED INVALID CREDENTIALS", "USER SERVICE",new Date()));
        throw new AuthenticationCredentialsNotFoundException("Invalid Credentials");

    }

    @Override
    public List<User> findAllUsers() {
        return urepo.findAll();
    }

    @Override
    public Optional<User> getUserByName(String name) {
        Optional<User> user=urepo.findByUsername(name);
        if(user.orElse(null)==null)
        {
            lRepo.save(new Errorlog("Error", "USERERROR", "409", "USER NOT FOUND WITH THE USERNAME", "USER SERVICE",new Date()));
            throw new UserNotFoundException("User was not found with user name "+name);
        }
        return user;

    }

    @Override
    public User updateUser(User user) {
        User oldUser=getByUserId(user.getUserId());
        if(oldUser==null)
        {
            lRepo.save(new Errorlog("Error", "USERERROR", "409", "USER NOT FOUND WITH", "USER SERVICE",new Date()));
            throw new UserNotFoundException("User not found...try login");
        }
            oldUser.setEmail(user.getEmail());
            oldUser.setPassword(passwordEncoder.encode(user.getPassword()));
            oldUser.setUsername(user.getUsername());
            oldUser.setMobileNumber(user.getMobileNumber());
            oldUser.setUserRole(user.getUserRole());
            return urepo.save(oldUser);
      
    }

    @Override
    public void deleteUser(int userId) {
        if(urepo.existsById(userId)){
        urepo.deleteById(userId);
        }
    }

    @Override
    public User getByUserId(int userId) {
        return urepo.findById(userId).orElse(null);
    }
    @Override
    public boolean verifyPassword(String userName,LoginRequestDTO requestDTO) {
        User user=urepo.findByUsername(userName).orElse(null);
        if(user==null)
        {
            lRepo.save(new Errorlog("Error", "USERERROR", "409", "USER NOT FOUND WITH THE USERNAME", "USER SERVICE",new Date()));
            throw new UserNotFoundException("User not found with username: "+userName);
        }
         if(passwordEncoder.matches(requestDTO.getPassword(),user.getPassword()))
        {
            return true;
        }
        lRepo.save(new Errorlog("Error", "USERERROR", "409", "USER PROVIDED INVALID CREDENTIALS", "USER SERVICE",new Date()));
        throw new AuthenticationCredentialsNotFoundException("Invalid Credentials");
    }   
}
