package com.examly.springapp.Exceptions;

public class AppointmentNotFound extends RuntimeException {
   public AppointmentNotFound(String s)
    {
        super(s);
    }
}
