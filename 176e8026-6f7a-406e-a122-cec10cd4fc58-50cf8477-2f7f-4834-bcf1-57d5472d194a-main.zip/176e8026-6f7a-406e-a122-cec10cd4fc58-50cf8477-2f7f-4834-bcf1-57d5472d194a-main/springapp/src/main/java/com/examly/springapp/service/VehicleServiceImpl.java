package com.examly.springapp.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.Exceptions.AppointmentNotFound;
import com.examly.springapp.Exceptions.VehicleNotFoundException;
import com.examly.springapp.model.Errorlog;
import com.examly.springapp.model.VehicleMaintenance;
import com.examly.springapp.repository.ErrorlogRepo;
import com.examly.springapp.repository.VehicleServiceRepo;

@Service
public class VehicleServiceImpl implements VehicleService
{
    @Autowired
    VehicleServiceRepo vehicleServiceRepo;
    @Autowired
    ErrorlogRepo lRepo;
    @Override
    public VehicleMaintenance addService(VehicleMaintenance service) 
    {
        return vehicleServiceRepo.save(service);
    }
    @Override
    public VehicleMaintenance updateService(Long serviceId, VehicleMaintenance service) 
    {
      VehicleMaintenance vehicleMaintenanceObj=vehicleServiceRepo.findById(serviceId).orElse(null);
      if(vehicleMaintenanceObj!=null)
      {
        vehicleMaintenanceObj.setServiceName(service.getServiceName());
        vehicleMaintenanceObj.setServicePrice(service.getServicePrice());
        vehicleMaintenanceObj.setTypeOfVehicle(service.getTypeOfVehicle());
        return vehicleServiceRepo.save(vehicleMaintenanceObj);
      }
      return vehicleMaintenanceObj;

    }
    @Override
    public void deleteService(Long serviceId) 
    {
        VehicleMaintenance vehicleMaintenanceObj=vehicleServiceRepo.findById(serviceId).orElse(null);
         if(vehicleMaintenanceObj==null)
        {
             lRepo.save(new Errorlog("Error", "USERERROR", "409", "VEHICLE NOT FOUND WITH"+serviceId, "VEHICLE SERVICE",new Date()));
           throw new VehicleNotFoundException("Vehicle Service not found with the "+serviceId);
        }
       
        vehicleServiceRepo.delete(vehicleMaintenanceObj);
    
    }

    @Override
    public List<VehicleMaintenance> getAllServices() 
    {
        return vehicleServiceRepo.findAll();
    }

    @Override
    public Optional<VehicleMaintenance> getServiceById(Long serviceId) 
    {
    return vehicleServiceRepo.findById(serviceId);
    }

    @Override
    public List<VehicleMaintenance> findByServiceName(String serviceName) 
    {
        return vehicleServiceRepo.findByServiceName(serviceName);
    }
    
}
