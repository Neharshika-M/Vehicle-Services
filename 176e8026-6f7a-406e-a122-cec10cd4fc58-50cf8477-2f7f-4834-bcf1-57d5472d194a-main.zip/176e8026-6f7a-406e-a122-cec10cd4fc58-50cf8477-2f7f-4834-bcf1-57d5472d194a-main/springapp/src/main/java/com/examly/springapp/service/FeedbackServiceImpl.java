package com.examly.springapp.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.Dto.FeedbackRequestDto;
import com.examly.springapp.Exceptions.FeedbackNotFoundException;
import com.examly.springapp.model.Errorlog;
import com.examly.springapp.model.Feedback;
import com.examly.springapp.model.User;
import com.examly.springapp.model.VehicleMaintenance;
import com.examly.springapp.repository.ErrorlogRepo;
import com.examly.springapp.repository.FeedbackRepo;

@Service
public class FeedbackServiceImpl implements FeedbackService{

    @Autowired
    FeedbackRepo repo;
    @Autowired
    UserService uservice;
    @Autowired
    VehicleService vService;
    @Autowired
    ErrorlogRepo lRepo;
    @Override
    public Feedback createFeedback(Feedback feedback) {
        return repo.save(feedback);
    }

    @Override
    public Feedback getFeedbackById(Long feedbackId) {
        return repo.findById(feedbackId).orElse(null);
    }

    @Override
    public List<Feedback> getAllFeedback() {
       return repo.findAll();
    }

    @Override
    public Feedback deleteFeedback(Long feedbackId) {
       Feedback f=getFeedbackById(feedbackId);
       if(f!=null){
        repo.delete(f);
        return f;
       }
       lRepo.save(new Errorlog("Error", "DATABASE", "409", "FEEDBACK NOT FOUND BY FEEDBACKID", "FEEDBACK Service",new Date()));
       return null;
    }

    @Override
    public List<Feedback> getFeedbackByUserId(Long userId) {
        return repo.findByUserUserId(userId.intValue());
    }

    @Override
    public Feedback updateFeedback(Long feedbackId, FeedbackRequestDto requestDto) {
        Feedback f=repo.findById(feedbackId).orElse(null);
        if(f==null) {

            throw new FeedbackNotFoundException("Feedback id not found");
        };
        User u=uservice.getByUserId(requestDto.getUserId());
        VehicleMaintenance v=vService.getServiceById(requestDto.getId()).orElse(null);
        if(f!=null){
            f.setMessage(requestDto.getMessage());
            f.setRating(requestDto.getRating());
            f.setUser(u);
            f.setVehicleMaintenance(v);
            return repo.save(f);
        }
        lRepo.save(new Errorlog("WARNING", "DATABASE", "409", "FEEDBACK NOT FOUND BY FEEDBACKID", "FEEDBACK Service",new Date()));
        return null;
    }

}
