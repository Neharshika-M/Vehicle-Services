
package com.examly.springapp.model;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Appointment
{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long appointmentId;
    private LocalDate appointmentDate;
    private String location;
    private String status="Pending";
    private boolean feedbackcompleted;
    public boolean isFeedbackcompleted() {
        return feedbackcompleted;
    }
    public void setFeedbackcompleted(boolean feedbackcompleted) {
        this.feedbackcompleted = feedbackcompleted;
    }
    @ManyToOne
    @JoinColumn(name="serviceId")
    private VehicleMaintenance vehicleMaintenance;
    @ManyToOne
    @JoinColumn(name="userId",nullable = false)
    private User user;
    public long getAppointmentId() {
        return appointmentId;
    }
    public void setAppointmentId(long appointmentId) {
        this.appointmentId = appointmentId;
    }
    public LocalDate getAppointmentDate() {
        return appointmentDate;
    }
    public void setAppointmentDate(LocalDate appointmentDate) {
        this.appointmentDate = appointmentDate;
    }
    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public VehicleMaintenance getVehicleMaintenance() {
        return vehicleMaintenance;
    }
    public void setVehicleMaintenance(VehicleMaintenance vehicleMaintenance) {
        this.vehicleMaintenance = vehicleMaintenance;
    }
    public User getUser() {
        return user;
    }
    public void setUser(User user) {
        this.user = user;
    }
    
}
