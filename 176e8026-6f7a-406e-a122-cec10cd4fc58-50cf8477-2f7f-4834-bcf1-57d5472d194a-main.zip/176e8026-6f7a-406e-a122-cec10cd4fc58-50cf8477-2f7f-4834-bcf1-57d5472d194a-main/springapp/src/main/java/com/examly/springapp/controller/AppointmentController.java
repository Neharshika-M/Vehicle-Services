package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.Dto.AppointmentRequestDto;
import com.examly.springapp.Dto.AppointmentResponseDto;
import com.examly.springapp.Exceptions.UserNotFoundException;
import com.examly.springapp.Exceptions.VehicleNotFoundException;
import com.examly.springapp.model.Appointment;
import com.examly.springapp.model.User;
import com.examly.springapp.model.VehicleMaintenance;
import com.examly.springapp.repository.UserRepo;
import com.examly.springapp.repository.VehicleServiceRepo;
import com.examly.springapp.service.AppointmentService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/")
public class AppointmentController {

    @Autowired
    AppointmentService service;
    @Autowired
    UserRepo uRepo;
    @Autowired 
    VehicleServiceRepo vRepo;

    @PreAuthorize("hasRole('USER')")
    @PostMapping("appointment")
    public ResponseEntity<Object> bookAppointment(@Valid @RequestBody AppointmentRequestDto requestDto)
    {
        Appointment appointment2=service.addAppointment(requestDto);
        if(appointment2!=null)
        {
        AppointmentResponseDto repsoneDto=new AppointmentResponseDto("Appointment created Successfully!!!",appointment2);
        return new ResponseEntity<Object>(repsoneDto, HttpStatusCode.valueOf(201));
        }
        return new ResponseEntity<>( "Error is occured while creating user",HttpStatusCode.valueOf(409));

    }

    @GetMapping("appointment/{userId}")
    public ResponseEntity<Object> getAppointmentByUserId(@PathVariable("userId") int userId)
    {
        List<Appointment> appointment2=service.getAppointmentsByUserId(userId);
        // if(!appointment2.isEmpty())
        // {
            AppointmentResponseDto repsoneDto=new AppointmentResponseDto("Successfully got list of appointments by userId",appointment2);
            return new ResponseEntity<Object>(repsoneDto, HttpStatusCode.valueOf(200));
        // }
        // return new ResponseEntity<Object>("Not list was found for user with"+userId,HttpStatusCode.valueOf(404));
    }
    //for admin only
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("appointment")
    public ResponseEntity<Object> getAllAppointment()
    {
        List<Appointment> listallAppointment=service.getAllAppointments();
        AppointmentResponseDto repsoneDto=new AppointmentResponseDto("Appointments got successfully!",listallAppointment);
        return new ResponseEntity<Object>(repsoneDto, HttpStatusCode.valueOf(200));
    }

    //for admin only
    @PutMapping("appointment/{appointmentId}")
    public ResponseEntity<Object> updateAppointment(@Valid @RequestBody AppointmentRequestDto requestDto,@PathVariable("appointmentId") long appointmentId)
    {
        Appointment appointment=new Appointment();
        User user=uRepo.findById(requestDto.getUserId()).orElse(null);
        if(user==null)
        {
            throw new UserNotFoundException("User was not found with the userId "+requestDto.getUserId());
        }
        VehicleMaintenance vehicle=vRepo.findById(requestDto.getId()).orElse(null);
        if(vehicle==null)
        {
            throw new VehicleNotFoundException("Vehicle was not found with the serviceId "+requestDto.getId());
        }
        //System.out.println(requestDto.getAppointmentDate());
        appointment.setAppointmentDate(requestDto.getAppointmentDate());
        appointment.setLocation(requestDto.getLocation());
        appointment.setUser(user);
        appointment.setVehicleMaintenance(vehicle);
        appointment.setStatus(requestDto.getStatus());
        appointment.setFeedbackcompleted(requestDto.isFeedbackcompleted());
        Appointment updateAppointment=service.updateAppointment(appointmentId,appointment);
        if(updateAppointment!=null)
        {
           AppointmentResponseDto repsoneDto=new AppointmentResponseDto("Appointment updated Successfully!!!",updateAppointment);
            return new ResponseEntity<Object>(repsoneDto,HttpStatusCode.valueOf(200));
        }
        return new ResponseEntity<Object>("Not updated",HttpStatusCode.valueOf(404));
    }

    @GetMapping("appointment/get/{appointmentId}")
    public ResponseEntity<?> getAppointmentById(@PathVariable long appointmentId)
    {
        Appointment appointment=service.getAppointmentById(appointmentId);
        return new ResponseEntity<>(appointment,HttpStatusCode.valueOf(200));
    }


    //for admin only
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("appointment/{appointmentId}")
    public ResponseEntity<Object> deleteAppointment(@PathVariable("appointmentId") long appointmentId)
    {
        boolean flag=service.deleteAppointment(appointmentId);
        if(flag)
        {
            return new ResponseEntity<Object>(HttpStatusCode.valueOf(204));
        }
        else
            return new ResponseEntity<Object>(HttpStatusCode.valueOf(404));
    }
}
