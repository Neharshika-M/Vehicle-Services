package com.examly.springapp.service;

import com.examly.springapp.Dto.LoginResponseDTO;

public interface OtpService {
    LoginResponseDTO verifyOtp(String email,String otp);
    boolean verifyOtpForUpdate(String email,String otp);
    boolean sendOtpEmail(String toEmail);

}
