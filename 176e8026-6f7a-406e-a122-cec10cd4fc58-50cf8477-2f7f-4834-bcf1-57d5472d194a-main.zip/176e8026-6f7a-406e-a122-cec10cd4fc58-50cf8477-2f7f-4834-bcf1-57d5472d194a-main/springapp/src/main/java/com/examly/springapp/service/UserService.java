package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import com.examly.springapp.Dto.LoginRequestDTO;
import com.examly.springapp.Dto.LoginResponseDTO;
import com.examly.springapp.model.User;

public interface UserService {
    User createUser(User user);
    LoginResponseDTO loadUserByUsername(String userName,LoginRequestDTO user); //return type should be userdetails.
    List<User> findAllUsers();
    User getByUserId(int userId); 
    void deleteUser(int userId);
    User updateUser(User user);
    Optional<User> getUserByName(String name); 
    boolean verifyPassword(String userName,LoginRequestDTO user);
}
