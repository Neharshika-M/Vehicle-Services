
package com.examly.springapp.Dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentRequestDto {
    @NotNull(message = "AppointmentDate cannot be null!!!")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate appointmentDate;
    @NotNull(message = "Location can not be empty | null")
    @NotBlank(message = "Location can not be empty | null")
    private String location;
    @NotNull(message = "UserId cannot be empty | null")
    @Positive(message = "userId cannot be negative or zero")
    private int userId;
    @NotNull(message = "ServiceId cannot be empty | null")
    @Positive(message = "serviceId cannot be negative or zero")
    private long id;
    private String status;
    private boolean feedbackcompleted=false;
}
