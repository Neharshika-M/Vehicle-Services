package com.examly.springapp.Dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VehicleMaintainRequestDto {

    @NotNull(message="Service Name cannot be null or empty!!!")
    private String serviceName;

    @NotNull(message="Service price cannot be null")
    @NotBlank(message="Service price cannot be empty or blank")
    @PositiveOrZero(message="Service Price cannot be negative please correct it")
    private int servicePrice;
    @NotBlank(message="Type of Vehicle cannot be empty")
    @NotNull(message="Type of Vehicle cannot be null")
    private String typeOfVehicle;
}
