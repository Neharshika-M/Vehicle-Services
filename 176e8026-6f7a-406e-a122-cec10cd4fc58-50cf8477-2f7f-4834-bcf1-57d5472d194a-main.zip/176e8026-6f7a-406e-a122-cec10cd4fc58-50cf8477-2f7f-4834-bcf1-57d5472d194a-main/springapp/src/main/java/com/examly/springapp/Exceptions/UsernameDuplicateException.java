package com.examly.springapp.Exceptions;

public class UsernameDuplicateException extends RuntimeException {
    public UsernameDuplicateException(String s)
    {
        super(s);
    }
}
