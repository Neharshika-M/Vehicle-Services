package com.examly.springapp.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.Dto.EmailDto;
import com.examly.springapp.Dto.EmailVerifyDto;
import com.examly.springapp.Dto.LoginResponseDTO;
import com.examly.springapp.service.OtpService;

@RestController
@RequestMapping("/api")
public class OtpController {

    @Autowired
    OtpService service;
    
    @PostMapping("/email/login")
    public ResponseEntity<Object> sendMailOtp(@RequestBody EmailDto requestDto)
    {
        Map<String,String> response=new HashMap<>();
        boolean  flag=service.sendOtpEmail(requestDto.getEmail());
        if(flag)
        {
            response.put("message","Otp has been sent successfully to registered email");
            return new ResponseEntity<>(response,HttpStatusCode.valueOf(200));
        }
        response.put("message", "Some confilt has raised");
        return new ResponseEntity<>(response,HttpStatusCode.valueOf(409));
    }
    @PostMapping("/email/verify")
    public ResponseEntity<?> verifyOtp(@RequestBody EmailVerifyDto requestDto)
    {
        Map<String,Object> response=new HashMap<>();
        LoginResponseDTO flag=service.verifyOtp(requestDto.getEmail(),requestDto.getOtp());
        if(flag!=null)
        {
            return new ResponseEntity<>(flag,HttpStatusCode.valueOf(200));
        }
        response.put("message","Invalid otp retry again");
        return new ResponseEntity<>(response,HttpStatusCode.valueOf(401));
    }
    @PostMapping("/otp/verify")
    public ResponseEntity<?> verifyOtpForUpdate(@RequestBody EmailVerifyDto requestDto)
    {
        Map<String,Object> response=new HashMap<>();
        boolean flag=service.verifyOtpForUpdate(requestDto.getEmail(),requestDto.getOtp());
        if(flag)
        {
            return new ResponseEntity<>(flag,HttpStatusCode.valueOf(200));
        }
        response.put("message","Invalid otp retry again");
        return new ResponseEntity<>(response,HttpStatusCode.valueOf(401));
    }

}