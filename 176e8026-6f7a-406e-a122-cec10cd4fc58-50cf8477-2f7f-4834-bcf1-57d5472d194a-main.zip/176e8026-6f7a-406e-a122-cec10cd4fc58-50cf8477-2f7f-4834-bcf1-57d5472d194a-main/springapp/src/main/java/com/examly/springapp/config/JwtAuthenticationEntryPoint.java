package com.examly.springapp.config;

 class JwtAuthenticationEntryPoint {
    
}
