package com.examly.springapp.controller;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.Dto.VehicleMaintainRequestDto;
import com.examly.springapp.Dto.VehicleMaintainResponseDto;
import com.examly.springapp.model.VehicleMaintenance;
import com.examly.springapp.service.VehicleServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/services")
public class VehicleServiceController
{
   @Autowired
    VehicleServiceImpl service;

    //for admin only
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<?>addService( @RequestBody VehicleMaintenance requestDto)
    {
        VehicleMaintenance obj=service.addService(requestDto);
        if(obj!=null)
        {
            return new ResponseEntity<>(obj,HttpStatusCode.valueOf(201));
        }
        else
        {
            return new ResponseEntity<>(HttpStatusCode.valueOf(403));
        }
    }

        // VehicleMaintenance vehicle=new VehicleMaintenance();
        // vehicle.setServiceName(requestDto.getServiceName());
        // vehicle.setServicePrice(requestDto.getServicePrice());
        // vehicle.setTypeOfVehicle(requestDto.getTypeOfVehicle());
        // VehicleMaintenance vehicleMaintenance=service.addService(vehicle);
        // if(obj!=null)
        // {
        //     VehicleMaintainResponseDto responseDto=new VehicleMaintainResponseDto("Vehicle Service created successfully!!!!",vehicleMaintenance);
        //     return new ResponseEntity<>(responseDto, HttpStatusCode.valueOf(201));
        // }
        // VehicleMaintainResponseDto responseDto=new VehicleMaintainResponseDto("Some error has been occured during creation of vehicle service","");
        // return new ResponseEntity<>(responseDto, HttpStatusCode.valueOf(403));


@PreAuthorize("hasRole('ADMIN')")
   @GetMapping("/service")
        public ResponseEntity<?> ViewServiceByServiceName(@RequestParam String serviceName) 
        {
    List<VehicleMaintenance> services = service.findByServiceName(serviceName);

    if (services != null && !services.isEmpty()) {
        return new ResponseEntity<>(services, HttpStatusCode.valueOf(200));
    } else {
        return new ResponseEntity<>(HttpStatusCode.valueOf(404));
    }
}
//for admin
@PreAuthorize("hasRole('ADMIN')")
@PutMapping("/{id}")
public ResponseEntity<?> UpdateServiceById(@PathVariable("id") long id, @RequestBody VehicleMaintenance serviceDetails) {
    VehicleMaintenance updatedService = service.updateService(id, serviceDetails);

    if (updatedService != null) {
        return new ResponseEntity<>(updatedService, HttpStatusCode.valueOf(200));
    } else {
        return new ResponseEntity<>("Service with ID " + id + " not found", HttpStatusCode.valueOf(404));
    }
}
//for all
@PreAuthorize("hasAnyRole('ADMIN','USER')")
@GetMapping
public ResponseEntity<?> viewAllServices() {
    List<VehicleMaintenance> services = service.getAllServices();
    return new ResponseEntity<>(services, HttpStatusCode.valueOf(200));
}
//for admin
@PreAuthorize("hasRole('ADMIN')")
@DeleteMapping("/{id}")
public ResponseEntity<?> deleteServiceById(@PathVariable("id") long id) {
    Optional<VehicleMaintenance> serviceObj = service.getServiceById(id);

    if (serviceObj.isPresent()) {
        service.deleteService(id);
        return new ResponseEntity<>(HttpStatusCode.valueOf(204)); // No Content
    } else {
        return new ResponseEntity<>("Service with ID " + id + " not found", HttpStatusCode.valueOf(404));
    }
}
@PreAuthorize("hasRole('ADMIN')")
@GetMapping("/{id}")
public ResponseEntity<Object> getServiceById(@PathVariable long id)
{
   VehicleMaintenance vehicle=service.getServiceById(id).orElse(null);
   if(vehicle!=null)
   {
    return new ResponseEntity<Object>(vehicle, HttpStatusCode.valueOf(200));
   }
   return new ResponseEntity<Object>("some error",HttpStatusCode.valueOf(404));
}
}
