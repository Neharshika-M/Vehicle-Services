package com.examly.springapp.repository;
import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.VehicleMaintenance;
@Repository
public interface VehicleServiceRepo extends JpaRepository<VehicleMaintenance,Long>
{
@Query("SELECT v FROM VehicleMaintenance v WHERE LOWER(v.serviceName) LIKE LOWER(CONCAT('%', :serviceName, '%'))")
    List<VehicleMaintenance> findByServiceName(@Param("serviceName") String serviceName);


}
