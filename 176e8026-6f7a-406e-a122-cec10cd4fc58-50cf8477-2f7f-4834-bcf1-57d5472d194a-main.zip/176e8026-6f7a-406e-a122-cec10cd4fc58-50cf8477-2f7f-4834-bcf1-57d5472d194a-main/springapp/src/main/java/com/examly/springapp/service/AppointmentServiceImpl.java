package com.examly.springapp.service;

import java.time.Instant;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.examly.springapp.Dto.AppointmentRequestDto;
import com.examly.springapp.Exceptions.AppointmentNotFound;
import com.examly.springapp.Exceptions.UserNotFoundException;
import com.examly.springapp.Exceptions.VehicleNotFoundException;
import com.examly.springapp.model.Appointment;
import com.examly.springapp.model.Errorlog;
import com.examly.springapp.model.User;
import com.examly.springapp.model.VehicleMaintenance;
import com.examly.springapp.repository.AppointmentRepo;
import com.examly.springapp.repository.ErrorlogRepo;
import com.examly.springapp.repository.UserRepo;
import com.examly.springapp.repository.VehicleServiceRepo;

import jakarta.mail.internet.MimeMessage;


@Service
public class AppointmentServiceImpl implements AppointmentService {

    @Autowired
    AppointmentRepo Arepo;
    @Autowired 
    UserRepo uRepo;
    @Autowired 
    VehicleServiceRepo vRepo;
    @Autowired
    ErrorlogRepo lRepo;
    @Autowired
    private JavaMailSender javaMailSender;
    private void sendAppointmentConfirmationEmail(User user, Appointment appointment) {
        try {
            MimeMessage mimeMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

            helper.setTo(user.getEmail());
            helper.setSubject("📅 Appointment Confirmation");
            String htmlContent = "<!DOCTYPE html>" +
                    "<html><head><style>" +
                    "body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }" +
                    ".container { background-color: #fff; padding: 20px; border-radius: 8px; max-width: 500px; margin: auto; }" +
                    "h2 { color: #2c3e50; } p { color: #555; }" +
                    "</style></head><body>" +
                    "<div class='container'>" +
                    "<h2>Hello " + user.getUsername() + ",</h2>" +
                    "<p>Your appointment has been successfully booked.</p>" +
                    "<p><strong>Date:</strong> " + appointment.getAppointmentDate() + "</p>" +
                    "<p><strong>Location:</strong> " + appointment.getLocation() + "</p>" +
                    "<p>We look forward to serving you!</p>" +
                    "<br><p>Best regards,<br><strong>Your Company Name</strong></p>" +
                    "</div></body></html>";
            helper.setText(htmlContent, true);
            javaMailSender.send(mimeMessage);
        } catch (Exception e) {
            lRepo.save(new Errorlog("Error", "Otp Generation", "409", "Error while generating otp for appointments", "appointment Service",new Date()));
            System.out.println("Failed to send appointment confirmation email: " + e.getMessage());
        }
    }

    private void sendAppointmentStatusUpdateEmail(User user, Appointment appointment) {
        try {
            MimeMessage mimeMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setTo(user.getEmail());
            helper.setSubject("🔔 Appointment Status Update");
            String htmlContent = "<!DOCTYPE html>" +
                    "<html><head><style>" +
                    "body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }" +
                    ".container { background-color: #fff; padding: 20px; border-radius: 8px; max-width: 500px; margin: auto; }" +
                    "h2 { color: #2c3e50; } p { color: #555; }" +
                    ".status { font-weight: bold; color: #27ae60; }" +
                    "</style></head><body>" +
                    "<div class='container'>" +
                    "<h2>Hello " + user.getUsername() + ",</h2>" +
                    "<p>The status of your appointment has been updated.</p>" +
                    "<p><strong>Date:</strong> " + appointment.getAppointmentDate() + "</p>" +
                    "<p><strong>Location:</strong> " + appointment.getLocation() + "</p>" +
                    "<p><strong>New Status:</strong> <span class='status'>" + appointment.getStatus() + "</span></p>" +
                    "<br><p>Best regards,<br><strong>Your Company Name</strong></p>" +
                    "</div></body></html>";
            helper.setText(htmlContent, true);
            javaMailSender.send(mimeMessage);

        } catch (Exception e) {
            System.out.println("Failed to send appointment status update email: " + e.getMessage());
        }
    }
    @Override
    public Appointment addAppointment(AppointmentRequestDto requestDto) {
        Appointment appointment=new Appointment();
        User user=uRepo.findById(requestDto.getUserId()).orElse(null);
        if(user==null)
        {
            lRepo.save(new Errorlog("Error", "DATABASE", "409", "USER NOT FOUND BY USERID", "appointment Service",new Date()));
            throw new UserNotFoundException("User was not found with the userId "+requestDto.getUserId());
        }
        VehicleMaintenance vehicle=vRepo.findById(requestDto.getId()).orElse(null);
        if(vehicle==null)
        {
            lRepo.save(new Errorlog("Error", "DATABSE", "409", "VEHICEL NOT FOUND BY VEHICLEID", "appointment Service",new Date()));
            throw new VehicleNotFoundException("Vehicle was not found with the serviceId "+requestDto.getId());
        }
        appointment.setAppointmentDate(requestDto.getAppointmentDate());
        appointment.setLocation(requestDto.getLocation());
        appointment.setUser(user);
        appointment.setVehicleMaintenance(vehicle);
        appointment.setFeedbackcompleted(requestDto.isFeedbackcompleted());
        sendAppointmentConfirmationEmail(user, appointment);
        return  Arepo.save(appointment); 
    }

    @Override
    public boolean deleteAppointment(long appointmentId) {
        Appointment appo=Arepo.findById(appointmentId).orElse(null);
        if(appo==null)
        {
            lRepo.save(new Errorlog("Error", "DATABSE", "409", "APPOINTMENTS NOT FOUND BY APPOINTMENTID", "appointment Service",new Date()));
           throw new AppointmentNotFound("Appointment not found with the "+appointmentId);
        }
        Arepo.delete(appo);
        return true;
    }

    @Override
    public Appointment getAppointmentById(long appointmentId) {
        Appointment appo=Arepo.findById(appointmentId).orElse(null);
        if(appo==null)
        {
            lRepo.save(new Errorlog("Error", "DATABASE", "409", "APPOINTMENTS NOT FOUND BY APPOINTMENTID", "appointment Service",new Date()));
            throw new AppointmentNotFound("Appointment not found with the "+appointmentId);
        }
        return appo;
    }

    @Override
    public List<Appointment> getAllAppointments() {
        return Arepo.findAll();
    }
    @Override
    public List<Appointment> getAppointmentsByUserId(int userId) {
        return Arepo.getAppointmentsByUserId(userId);
    }
    @Override
    public Appointment updateAppointment(long appointmentId, Appointment appointment) {
        Appointment appo=Arepo.findById(appointmentId).orElse(null);
        if (appo==null) {
            lRepo.save(new Errorlog("Error", "DATABASE", "409", "APPOINTMENTS NOT FOUND BY APPOINTMENTID", "appointment Service",new Date()));
            throw new AppointmentNotFound("Appointment not found with the "+appointmentId);
        }
        appo.setAppointmentDate(appointment.getAppointmentDate());
       // appo.setAppointmentId(appointment.getAppointmentId());
        appo.setLocation(appointment.getLocation());
        appo.setStatus(appointment.getStatus());
        appo.setFeedbackcompleted(appointment.isFeedbackcompleted());
        Arepo.save(appo);
        sendAppointmentStatusUpdateEmail(appo.getUser(), appo);
        return appo;
    }
    
}







