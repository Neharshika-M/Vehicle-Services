package com.examly.springapp.Dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginRequestDTO {
    @NotNull(message = "User name cannot be null")
    @NotBlank(message="User name cannot be empty")
    private String username;
    @NotNull(message = "Password cannot be null")
    @NotBlank(message="Password cannot be empty")
    private String password;
}
