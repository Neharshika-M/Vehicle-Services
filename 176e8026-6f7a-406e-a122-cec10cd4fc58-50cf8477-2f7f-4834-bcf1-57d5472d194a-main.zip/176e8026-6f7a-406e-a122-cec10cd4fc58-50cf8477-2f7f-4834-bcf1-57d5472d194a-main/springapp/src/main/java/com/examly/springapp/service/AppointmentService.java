package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.Dto.AppointmentRequestDto;
import com.examly.springapp.model.Appointment;

public interface AppointmentService {

    Appointment addAppointment(AppointmentRequestDto appointment);
    boolean deleteAppointment(long appointmentId);
    Appointment getAppointmentById(long appointmentId);
    List<Appointment> getAllAppointments();
   List<Appointment> getAppointmentsByUserId(int userId);
    Appointment updateAppointment(long appointmentId,Appointment appointment);
}
