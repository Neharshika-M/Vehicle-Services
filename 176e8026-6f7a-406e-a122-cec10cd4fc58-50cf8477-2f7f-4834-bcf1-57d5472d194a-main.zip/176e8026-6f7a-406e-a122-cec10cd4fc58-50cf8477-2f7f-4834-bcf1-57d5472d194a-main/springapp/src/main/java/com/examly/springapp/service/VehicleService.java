package com.examly.springapp.service;


import com.examly.springapp.model.VehicleMaintenance;
import java.util.*;

public interface VehicleService 
{
    VehicleMaintenance addService(VehicleMaintenance service);
    VehicleMaintenance updateService(Long serviceId,VehicleMaintenance service);
    void deleteService(Long serviceId);
    List<VehicleMaintenance> getAllServices();
    Optional<VehicleMaintenance>getServiceById(Long serviceId);
    List<VehicleMaintenance>findByServiceName(String serviceName);
}
