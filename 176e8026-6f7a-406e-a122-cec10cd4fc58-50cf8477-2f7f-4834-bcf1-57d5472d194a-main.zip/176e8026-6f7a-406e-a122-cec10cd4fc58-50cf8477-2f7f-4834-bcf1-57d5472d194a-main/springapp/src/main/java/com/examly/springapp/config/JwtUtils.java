package com.examly.springapp.config;

import java.util.function.Function;
import java.security.Key;
import java.util.*;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtils {

    @Value("${API_JWT_SECRET}")
    private String secretKey;

    // public String getKey()
    // {
    //     return secretKey;
    // }
    public Claims extractAllClaims(String token)
    {
        // return Jwts.parser()
        // .setSigningKey(getSignKey())
        // .parseClaimsJws(token)
        // .getBody();
        return Jwts.parserBuilder()
        .setSigningKey(getSignKey())
        .build().
        parseClaimsJws(token)
        .getBody();
    }
    public <T> T extractClaim(String token,Function<Claims,T> claimsReslover)
    {
        final Claims claim=extractAllClaims(token);
        return claimsReslover.apply(claim);
    }
    public String extractUsername(String token)
    {
        return extractClaim(token,Claims::getSubject);
    }
    public Date extractExpirationDate(String token)
    {
        return extractClaim(token, Claims::getExpiration);
    }
    public boolean isTokenExpired(String token)
    {
        return extractExpirationDate(token).before(new Date());
    }
    public String createToken(Map<String,Object> claims,String subject)
    {
        return Jwts.builder()
        .setClaims(claims)
        .setSubject(subject)
        .setIssuedAt(new Date(System.currentTimeMillis()))
        .setExpiration(new Date(System.currentTimeMillis()+1000*60*60*24))
        .signWith(getSignKey(),SignatureAlgorithm.HS256)
        .compact();
    }
    private Key getSignKey()
    {
        byte[] keyBytes=Decoders.BASE64.decode(secretKey);
        return Keys.hmacShaKeyFor(keyBytes);
    }
    public String generateToken(String username)
    {
        Map<String,Object> claims=new HashMap<>();
        return createToken(claims, username);
    }
    public boolean validateToken(String token,UserDetails userdetails)
    {
        String usernameString=extractUsername(token);
        return (usernameString.equals(userdetails.getUsername())&&!isTokenExpired(token));
    }
}
