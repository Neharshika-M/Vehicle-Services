package com.examly.springapp.Dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
public class LoginResponseDTO {
    private String username;
    private String token;
    private String userRole;
    private int userId;
    private long createdAt;
}
