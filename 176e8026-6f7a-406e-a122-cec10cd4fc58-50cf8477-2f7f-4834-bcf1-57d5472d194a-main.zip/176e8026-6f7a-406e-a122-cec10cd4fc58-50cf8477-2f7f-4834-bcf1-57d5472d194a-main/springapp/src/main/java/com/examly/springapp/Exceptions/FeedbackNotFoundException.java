package com.examly.springapp.Exceptions;

public class FeedbackNotFoundException extends RuntimeException {
    public FeedbackNotFoundException(String msg){
        super(msg);
    }

}
