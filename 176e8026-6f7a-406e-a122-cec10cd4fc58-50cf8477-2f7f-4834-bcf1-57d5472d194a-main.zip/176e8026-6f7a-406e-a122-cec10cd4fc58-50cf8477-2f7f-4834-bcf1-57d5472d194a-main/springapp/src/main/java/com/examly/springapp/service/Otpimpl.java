package com.examly.springapp.service;

import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.examly.springapp.Dto.LoginResponseDTO;
import com.examly.springapp.Exceptions.OtpException;
import com.examly.springapp.Exceptions.UserNotFoundException;
import com.examly.springapp.config.JwtUtils;
import com.examly.springapp.model.Errorlog;
import com.examly.springapp.model.Otp;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.ErrorlogRepo;
import com.examly.springapp.repository.OtpRepo;
import com.examly.springapp.repository.UserRepo;

import jakarta.mail.internet.MimeMessage;

@Service
public class Otpimpl implements OtpService {

    private JavaMailSender javaMailSender;
    private Map<String,String> otpStoarge=new HashMap<>();

    @Autowired
    OtpRepo oRepo;
    @Autowired
    UserRepo urepo;
    @Autowired
    ErrorlogRepo lRepo;
    @Autowired
    private JwtUtils jwtUtils;

    public Otpimpl(JavaMailSender javaMailSender)
    {
        this.javaMailSender=javaMailSender;
    }
      public String generateOtp() {
        int otp = ThreadLocalRandom.current().nextInt(1000, 9999);
        return String.valueOf(otp);
    }
    @Override
public boolean sendOtpEmail(String toEmail) {
    User user = urepo.findByEmail(toEmail);
    if (user == null) {
        lRepo.save(new Errorlog("Error", "DATABASE", "409", "USER NOT FOUND WITH USERID", "OTP Service",new Date()));
        throw new UserNotFoundException("User not found with this email! Please Register");
    }

    try {
        String otp = generateOtp();
        toEmail = toEmail.trim().toLowerCase();
        Otp alreadyExists = oRepo.findByEmail(toEmail);

        otpStoarge.put(toEmail, otp);

        // Use MimeMessage for HTML email
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

        helper.setTo(toEmail);
        helper.setSubject("🔐 Your One-Time Password (OTP)");

        // HTML email body`
        String htmlContent = "<!DOCTYPE html>" +
                "<html>" +
                "<head>" +
                "<style>" +
                "body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }" +
                ".container { background-color: #ffffff; padding: 20px; border-radius: 8px; max-width: 500px; margin: auto; }" +
                "h2 { color: #333333; }" +
                ".otp { font-size: 24px; font-weight: bold; color: #2c3e50; letter-spacing: 4px; }" +
                "p { color: #555555; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "<div class='container'>" +
                "<h2>Dear " + user.getUsername() + ",</h2>" +
                "<p>We received a request to verify your email address. Please use the OTP below to complete your verification process:</p>" +
                "<p class='otp'>" + otp + "</p>" +
                "<p>This OTP is valid for <strong>2 minutes</strong>. Do not share it with anyone for security reasons.</p>" +
                "<p>If you did not request this, please ignore this email.</p>" +
                "<br>" +
                "<p>Best regards,<br><strong>Vehicle Service</strong></p>" +
                "</div>" +
                "</body>" +
                "</html>";

        helper.setText(htmlContent, true); // true = HTML

        javaMailSender.send(mimeMessage);
        // Save OTP in DB
        if (alreadyExists != null) {
            alreadyExists.setOtp(otp);
            oRepo.save(alreadyExists);
        } else {
            Otp otpEntity = new Otp();
            otpEntity.setEmail(toEmail);
            otpEntity.setOtp(otp);
            oRepo.save(otpEntity);
        }

        return true;
    } catch (Exception e) {
        lRepo.save(new Errorlog("Error", "DATABASE", "404", "OTP WAS NOT GENERATING", "OTP Service",new Date()));
        System.out.println(e.getMessage());
        return false;
    }
}
    @Override
    public LoginResponseDTO verifyOtp(String email, String enteredOtp) {
        Otp otp=oRepo.findByEmail(email);
        if(otp==null)
        {
            lRepo.save(new Errorlog("Error", "DATABASE", "409", "USER NOT FOUND WITH EMAIL", "OTP Service",new Date()));
            throw new UserNotFoundException("User not found with this email! Please Register");
        }
        String exisitingOtp=otp.getOtp();
        boolean equal = exisitingOtp.equals(enteredOtp);
        if(!equal)
        {
            lRepo.save(new Errorlog("Error", "USER_ERROR", "401", "INVALID OTP ACCESSED", "OTP Service",new Date()));
                throw new OtpException("Invalid otp");
        }
        User user=urepo.findByEmail(email);
        LoginResponseDTO responseDto= new LoginResponseDTO(user.getUsername(),jwtUtils.generateToken(user.getUsername()), user.getUserRole(),user.getUserId(),Instant.now().toEpochMilli());
        return responseDto;
    }
    @Override
    public boolean verifyOtpForUpdate(String email, String enteredOtp) {
        Otp otp=oRepo.findByEmail(email);
        if(otp==null)
        {
            lRepo.save(new Errorlog("Error", "USER_ERROR", "409", "USER NOT FOUND WITH EMAIL", "OTP Service",new Date()));
            throw new UserNotFoundException("User not found with this email! Please Register");
        }
        String exisitingOtp=otp.getOtp();
        boolean equal = exisitingOtp.equals(enteredOtp);
        if(!equal)
        {
            lRepo.save(new Errorlog("Error", "USER_ERROR", "401", "INVALID OTP ACCESSED", "OTP Service",new Date()));
            throw new OtpException("Invalid otp");
        }
        return true;
    }
}
