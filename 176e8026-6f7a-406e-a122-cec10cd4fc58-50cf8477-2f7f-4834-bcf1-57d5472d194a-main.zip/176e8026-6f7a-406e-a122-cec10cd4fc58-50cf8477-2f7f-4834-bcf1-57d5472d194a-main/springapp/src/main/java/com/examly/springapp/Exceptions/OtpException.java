package com.examly.springapp.Exceptions;

public class OtpException extends RuntimeException {
    public OtpException(String s)
    {
        super(s);
    }
}
