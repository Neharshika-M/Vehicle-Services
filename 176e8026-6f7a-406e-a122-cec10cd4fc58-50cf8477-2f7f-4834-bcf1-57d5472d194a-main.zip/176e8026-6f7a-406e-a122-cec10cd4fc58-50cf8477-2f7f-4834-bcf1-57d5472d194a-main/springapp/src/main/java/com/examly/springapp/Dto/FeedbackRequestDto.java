package com.examly.springapp.Dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FeedbackRequestDto {
    private String message;
    private int rating;
    private int userId;
    private long id;
}
