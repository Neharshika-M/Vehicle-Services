package com.examly.springapp.controller;

import java.net.http.HttpResponse;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.Dto.FeedbackRequestDto;
import com.examly.springapp.Exceptions.UserNotFoundException;
import com.examly.springapp.Exceptions.VehicleNotFoundException;
import com.examly.springapp.model.Feedback;
import com.examly.springapp.model.User;
import com.examly.springapp.model.VehicleMaintenance;
import com.examly.springapp.repository.UserRepo;
import com.examly.springapp.repository.VehicleServiceRepo;
import com.examly.springapp.service.FeedbackService;

import jakarta.validation.Valid;

@RestController
public class FeedbackController {
    @Autowired
    FeedbackService service;
    @Autowired
    UserRepo uRepo;
    @Autowired
    VehicleServiceRepo vRepo;
    //for user
    @PreAuthorize("hasRole('USER')")
    @PostMapping("/api/feedback")
    public ResponseEntity<?> createFeedback(@Valid @RequestBody FeedbackRequestDto requestDto){
        Feedback feedback=new Feedback();
        User user=uRepo.findById(requestDto.getUserId()).orElse(null);
        if(user==null){
            throw new UserNotFoundException("User not found with userId "+requestDto.getUserId());
        }
        VehicleMaintenance vehicle=vRepo.findById(requestDto.getId()).orElse(null);
        if(vehicle==null)
        {
            throw new VehicleNotFoundException("Vehicle service is found "+requestDto.getId());
        }
        feedback.setMessage(requestDto.getMessage());
        feedback.setRating(requestDto.getRating());
        feedback.setUser(user);
        feedback.setVehicleMaintenance(vehicle);
        Feedback feedback2=service.createFeedback(feedback);
        if(feedback2!=null)
        {
            return new ResponseEntity<>(feedback2, HttpStatusCode.valueOf(201));
        }
        return new ResponseEntity<>("Not created", HttpStatusCode.valueOf(409));
    }
    //for admin
     @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/api/feedback")
    public ResponseEntity<?> getAllFeedback(){
        List<Feedback> f=service.getAllFeedback();
        return new ResponseEntity<>(f,HttpStatusCode.valueOf(200));
    }
    @GetMapping("/api/feedback/{feedbackId}")
    public ResponseEntity<?> getAllFeedbackById(@PathVariable Long feedbackId){
        Feedback f=service.getFeedbackById(feedbackId);
        return new ResponseEntity<>(f,HttpStatusCode.valueOf(200));
    }

    //for user
    @GetMapping("/api/feedback/user/{userId}")
    public ResponseEntity<?> getFeedbackByUserId(@PathVariable long userId){
        List<Feedback> f=service.getFeedbackByUserId(userId);
        return new ResponseEntity<>(f,HttpStatusCode.valueOf(200));

    }
    //for user
    @PreAuthorize("hasRole('USER')")
    @DeleteMapping("/api/feedback/{id}")
    public ResponseEntity<?> deleteFeedback(@PathVariable Long id){
        Feedback f=service.deleteFeedback(id);
        return new ResponseEntity<>(f,HttpStatusCode.valueOf(204));
    }

    @PutMapping("/api/feedback/{id}")
    public ResponseEntity<?> updateFeedback(@PathVariable Long id,@RequestBody FeedbackRequestDto feedback){
        Feedback f=service.updateFeedback(id, feedback);
        if(f==null) return new ResponseEntity<>("feedback in mull",HttpStatusCode.valueOf(400));
        return new ResponseEntity<>(f,HttpStatusCode.valueOf(200));
    }
    
}
