package com.examly.springapp.Exceptions;

import java.nio.file.AccessDeniedException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalException {

    @ExceptionHandler(AppointmentNotFound.class)
    public ResponseEntity<Object> appointmentNotFound(Exception e)
    {
        return new ResponseEntity<>(e.getMessage(), HttpStatusCode.valueOf(404));
    }
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<Object> userNotFound(Exception e)
    {
        Map<String,String> error=new HashMap<>();
        error.put("message",e.getMessage());
        error.put("status",HttpStatus.UNAUTHORIZED+"");
        return new ResponseEntity<>(error, HttpStatusCode.valueOf(401));
    }
    @ExceptionHandler(VehicleNotFoundException.class)
    public ResponseEntity<Object> vehicleNotFound(Exception e)
    {
        return new ResponseEntity<>(e.getMessage(),HttpStatusCode.valueOf(409));
    }
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Object> handlingException(MethodArgumentNotValidException e)
    {
        Map<String,String> errors=new HashMap<>();
        e.getBindingResult().getFieldErrors().forEach(error->
        {
            errors.put(error.getField(),error.getDefaultMessage());
        });
        return new ResponseEntity<>(errors, HttpStatusCode.valueOf(400));
    }
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Object> handleUnreadException(HttpMessageNotReadableException e)
    {
        Map<String,String> errors=new HashMap<>();
        errors.put("error", "Invalid request format");
        errors.put("details",e.getMostSpecificCause().getMessage());
        return new ResponseEntity<>(errors,HttpStatusCode.valueOf(400));
    }
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<Object> handleAccessDenied(AccessDeniedException e)
    {
        Map<String,Object> response=new HashMap<>();
        response.put("status",HttpStatus.FORBIDDEN.value());
        response.put("message","you dont have permission to access this resource");
        return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
    }
    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<Object> handleAuthentication(AuthenticationException e)
    {
        Map<String,Object> response=new HashMap<>();
        response.put("status",HttpStatus.FORBIDDEN.value());
        response.put("message",e.getMessage());
        return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(UsernameDuplicateException.class)
    public ResponseEntity<Object> usernameDuplicate(Exception e)
    {
        Map<String,String> error=new HashMap<>();
        error.put("message",e.getMessage());
        error.put("status",HttpStatus.CONFLICT+"");
        return new ResponseEntity<>(error,HttpStatusCode.valueOf(409));
    }
    @ExceptionHandler(AuthenticationCredentialsNotFoundException.class)
    public ResponseEntity<Object> userInvalidCreditanls(Exception e)
    {
        Map<String,String> error=new HashMap<>();
        error.put("message",e.getMessage());
        error.put("status",HttpStatus.UNAUTHORIZED+"");
        return new ResponseEntity<>(error,HttpStatus.UNAUTHORIZED);
    }
    @ExceptionHandler(OtpException.class)
    public ResponseEntity<Object> otpException(Exception e)
    {
        Map<String,String> error=new HashMap<>();
        error.put("message",e.getMessage());
        error.put("status",HttpStatus.UNAUTHORIZED+"");
        return new ResponseEntity<>(error,HttpStatus.UNAUTHORIZED);
    }
    @ExceptionHandler(FeedbackNotFoundException.class)
    public ResponseEntity<Object> FeedbackNotFoundException(Exception e)
    {
        Map<String,String> error=new HashMap<>();
        error.put("message",e.getMessage());
        error.put("status",HttpStatus.NOT_FOUND+"");
        return new ResponseEntity<>(error,HttpStatus.NOT_FOUND);
    }
}
