package com.examly.springapp.Exceptions;

public class VehicleNotFoundException extends RuntimeException  {

    public VehicleNotFoundException(String s)
    {
        super(s);
    }
}
