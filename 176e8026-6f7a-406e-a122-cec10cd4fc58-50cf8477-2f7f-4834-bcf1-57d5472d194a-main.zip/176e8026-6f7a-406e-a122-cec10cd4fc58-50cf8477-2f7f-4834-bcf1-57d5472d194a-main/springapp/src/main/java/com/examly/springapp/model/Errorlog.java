package com.examly.springapp.model;
import java.util.Date;

import jakarta.annotation.Generated;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
public class Errorlog {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String errorlevel;
    private String errortype;
    private String httpstatuscode;
    private String message;
    private String service_name;
    private Date timestamp;
    public Errorlog(String errorlevel, String errortype, String httpstatuscode, String message, String service_name,
            Date timestamp) {
        this.errorlevel = errorlevel;
        this.errortype = errortype;
        this.httpstatuscode = httpstatuscode;
        this.message = message;
        this.service_name = service_name;
        this.timestamp = timestamp;
    }
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getErrorlevel() {
        return errorlevel;
    }
    public void setErrorlevel(String errorlevel) {
        this.errorlevel = errorlevel;
    }
    public String getErrortype() {
        return errortype;
    }
    public void setErrortype(String errortype) {
        this.errortype = errortype;
    }
    public String getHttpstatuscode() {
        return httpstatuscode;
    }
    public void setHttpstatuscode(String httpstatuscode) {
        this.httpstatuscode = httpstatuscode;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public String getService_name() {
        return service_name;
    }
    public void setService_name(String service_name) {
        this.service_name = service_name;
    }
    public Date getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }
}
