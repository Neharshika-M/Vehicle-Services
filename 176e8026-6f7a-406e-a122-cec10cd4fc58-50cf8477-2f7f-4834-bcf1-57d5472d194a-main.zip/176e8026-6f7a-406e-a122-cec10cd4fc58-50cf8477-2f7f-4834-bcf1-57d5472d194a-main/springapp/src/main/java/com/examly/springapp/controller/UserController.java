package com.examly.springapp.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.Dto.LoginRequestDTO;
import com.examly.springapp.Dto.LoginResponseDTO;
import com.examly.springapp.model.User;
import com.examly.springapp.service.UserService;

import jakarta.validation.Valid;

@RestController
public class UserController {
    @Autowired 
    private UserService service;

    @PostMapping("/api/register")
    public ResponseEntity<Object>createUser(@Valid @RequestBody User user)
    {
        User user2=service.createUser(user);
        if(user2!=null)
        {
            return new ResponseEntity<Object>(user2,HttpStatusCode.valueOf(201));
        }
        return new ResponseEntity<Object>("User cannot be created successfull",HttpStatusCode.valueOf(400));
    }

    @PostMapping("/api/login")
    public ResponseEntity<Object> loginUser( @Valid @RequestBody LoginRequestDTO requestDTO)
    {
        LoginResponseDTO user=service.loadUserByUsername(requestDTO.getUsername(),requestDTO);
        if(user!=null)
        {
            return new ResponseEntity<Object>(user, HttpStatusCode.valueOf(200));
        }
        return new ResponseEntity<Object>("Some error", HttpStatusCode.valueOf(404));
    }

    //for admin
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/api/user")
    public ResponseEntity<List<User>> findAllUsers()
    {
        List<User> u=service.findAllUsers();
        return new ResponseEntity<>(u,HttpStatusCode.valueOf(200));
    }

    //for admin
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/api/{id}")
    public ResponseEntity<?>deleteUser(@PathVariable int id)
    {
        User user = service.getByUserId(id);
        if (user == null) {
            return  new ResponseEntity<>(HttpStatusCode.valueOf(404)); // 404 Not Found
        }
        service.deleteUser(id);
        return new ResponseEntity<>(user,HttpStatusCode.valueOf(204)); // 204 No Content
    
    }
    
    //for user
    @PreAuthorize("hasRole('USER')")
    @PutMapping("/api/user/view/profile")
    public ResponseEntity<User>updateUser(@Valid @RequestBody User user)
    {
        User u=service.updateUser(user);
        if(u!=null)
        {
            return new ResponseEntity<>(u,HttpStatusCode.valueOf(200));
        }
        else
        {
            return new ResponseEntity<>(HttpStatusCode.valueOf(404));
        }
    }

    //for user
    @PreAuthorize("hasRole('USER')")
    @GetMapping("/api/user/{userId}")
    public ResponseEntity<User>getbyUserId(@PathVariable int userId)
    {
        User u=service.getByUserId(userId);
        if(u==null)
        {
            return new ResponseEntity<>(HttpStatusCode.valueOf(404));
        }
        else
        {
            return new ResponseEntity<>(u,HttpStatusCode.valueOf(200));
        }
    }

    //for admin
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/api/name/{name}")
    public ResponseEntity<User>getUserByName(@PathVariable String name)
    {
        Optional<User> u=service.getUserByName(name);
        if(u.isPresent())
        {
            return new ResponseEntity<>(u.get(),HttpStatusCode.valueOf(200));
        }
        else
        {
            return new ResponseEntity<>(HttpStatusCode.valueOf(404));
        }
    }

    // @PreAuthorize("hasRole('USER')")
    @PostMapping("/api/verifyPassword")
    public ResponseEntity<?> verifyPassword(@RequestBody LoginRequestDTO requestDTO){
        boolean isVerified=service.verifyPassword(requestDTO.getUsername(),requestDTO);
        if(isVerified) return new ResponseEntity<>(isVerified,HttpStatusCode.valueOf(200));
        return new ResponseEntity<>(HttpStatusCode.valueOf(404));
        

    }
    
}
